import React, { useState } from 'react';
import { StudyResource } from '../types';
import { Book, Youtube, Globe, AlertCircle, ShoppingCart, ExternalLink, ChevronDown, ChevronUp, Star, AlertTriangle, Info, MapPin, Zap, MonitorPlay, Headphones } from 'lucide-react';
import StudyStrategy from './StudyStrategy';

const Resources: React.FC = () => {
  const [filter, setFilter] = useState<'All' | 'Book' | 'YouTube' | 'QBank'>('All');
  const [expandedResource, setExpandedResource] = useState<string | null>(null);

  const resources: StudyResource[] = [
    {
      id: '1',
      title: 'Saunders Comprehensive Review (9th Ed)',
      type: 'Book',
      author: 'Silvestri',
      description: 'The "Bible" of NCLEX prep. Best for building content foundation in Year 2-3.',
      link: 'https://www.amazon.com/Saunders-Comprehensive-Review-NCLEX-RN%C2%AE-Examination/dp/0323795307',
      recommendedFor: 'Content Mastery',
      tags: ['Must Have', 'Fundamentals', 'MedSurg'],
      price: "1200 - 1500 BDT (Nilkhet Reprint)",
      bestPhase: 'Phase 1: Content',
      studyStrategy: "Do NOT read this cover-to-cover like a novel. You will fall asleep. \n\n1. Take the pre-test at the beginning of a chapter.\n2. Only read the sections you scored poorly on.\n3. CRITICAL: Read every 'Pyramid Point' and 'red text' boxes. These are high-yield NCLEX questions.\n4. Do the questions at the end of the chapter immediately.",
      warning: "Don't try to memorize the specific dosage of every med. Saunders has too much detail. Focus on classifications."
    },
    {
      id: '2',
      title: 'UWorld NCLEX-RN QBank',
      type: 'QBank',
      description: 'The gold standard. If you can only buy ONE thing, buy this. The rationales are textbooks themselves.',
      link: 'https://nursing.uworld.com/nclex-rn/',
      recommendedFor: 'Practice Questions',
      tags: ['Critical Thinking', 'Exam Simulation'],
      price: "$139 - $169 USD (~18k BDT)",
      bestPhase: 'Phase 3: Practice',
      studyStrategy: "Treat UWorld as a learning tool, not an assessment. \n\n1. Do 75 questions in 'Timed' mode to build stamina.\n2. The Magic: Read the rationale for EVERY question, even the ones you got right. \n3. Make a digital notebook (Flashcards) of concepts you missed.\n4. Aim for 60% average. If you get 60% consistently, you have a 92% chance of passing NCLEX.",
      warning: "Do not use 'Tutor Mode' all the time. It makes you weak. You need to get used to the anxiety of not knowing the answer immediately."
    },
    {
      id: '3',
      title: 'Mark Klimek Lectures (Blue/Yellow Book)',
      type: 'Book',
      description: 'The cult classic. Mark K teaches you how to pass the exam, not just nursing info.',
      link: 'https://www.studocu.com/en-us/document/massachusetts-college-of-pharmacy-and-health-sciences/nursing-leadership/mark-k-yellow-book-lecture-notes/23240254',
      recommendedFor: 'Strategy',
      tags: ['Audio', 'Notes', 'Strategy'],
      price: "Free (Find on Telegram/Spotify)",
      bestPhase: 'Phase 2: Strategy',
      studyStrategy: "Listen to the 12 audio lectures. \n\n1. Lecture 12 (Prioritization) is the most important hour of your life. Listen to it 5 times.\n2. Lecture on 'Maternal' and 'Psych' are gold.\n3. He teaches tricks like 'As the pH goes, so goes my patient'. Memorize these verbatim.",
      warning: "His pharmacologies are slightly outdated, but his principles/strategies are timeless. Use SimpleNursing for updated Pharm."
    },
    {
      id: '4',
      title: 'SimpleNursing',
      type: 'YouTube',
      description: 'Visual learning with cartoons. The best for Pharmacology and EKG strips.',
      link: 'https://www.youtube.com/c/SimpleNursing',
      recommendedFor: 'Visual Learners',
      tags: ['Pharmacology', 'Visuals'],
      price: "Free (YouTube) / Paid Subscription",
      bestPhase: 'Phase 1: Content',
      studyStrategy: "Use this for topics you just CANNOT understand in Saunders.\n\n1. Great for EKG Rhythms (Visuals help).\n2. Best for Pharmacology mnemonics.\n3. Don't watch passively. Draw the diagrams he draws.",
      warning: "Don't rely ONLY on videos. You must do questions to test if you actually understood it."
    },
    {
      id: '8',
      title: 'RegisteredNurseRN',
      type: 'YouTube',
      author: 'Nurse Sarah',
      description: 'The clearest teacher on YouTube. Excellent for Skills, Procedures, and Fundamentals foundations.',
      link: 'https://www.youtube.com/user/RegisteredNurseRN',
      recommendedFor: 'Foundations & Skills',
      tags: ['Skills', 'Easy English'],
      price: "Free",
      bestPhase: 'Phase 1: Content',
      studyStrategy: "Sarah is the queen of explaining 'How to do things'. \n\n1. Watch her 'Nursing Skills' playlist for hospital rotations (IVs, Foleys, NG Tubes).\n2. Her 'ECG Rhythms' video is legendary.\n3. Take the free quizzes on her website after watching videos.",
      warning: "Her videos can be long. Watch at 1.5x speed if you are reviewing."
    },
    {
      id: '7',
      title: 'Nexus Nursing',
      type: 'YouTube',
      author: 'Prof D',
      description: 'Tough love style. She reads the question, yells at you for choosing the wrong answer, and explains WHY.',
      link: 'https://www.youtube.com/c/nexusnursing',
      recommendedFor: 'Question Breakdown',
      tags: ['Audio', 'Mental Health'],
      price: "Free",
      bestPhase: 'Phase 3: Practice',
      studyStrategy: "Watch her 'Saturday Night' live replays. \n\n1. She is excellent for Mental Health and MedSurg.\n2. She forces you to read the question carefully without adding your own assumptions.\n3. Great to listen to like a podcast while commuting.",
      warning: "She speaks fast and uses slang. Might be hard initially, but stick with it."
    },
    {
      id: '9',
      title: 'NCLEX Crusade International',
      type: 'YouTube',
      author: 'Mr. C',
      description: 'Specifically designed for ESL (English as Second Language) students. Teaches the "Logic" of the question.',
      link: 'https://www.youtube.com/c/NCLEXCrusadeInternational',
      recommendedFor: 'Critical Thinking',
      tags: ['ESL Friendly', 'Logic'],
      price: "Free",
      bestPhase: 'Phase 2: Strategy',
      studyStrategy: "MANDATORY: Watch his '7 Day Training' playlist. \n\n1. He teaches you how to deconstruct the grammar of the question.\n2. Helps you identify 'Distractors' vs 'Correct Answers'.\n3. Perfect if you know the content but keep picking the wrong answer.",
      warning: "Do not skip the intro videos. You need to understand his method."
    },
    {
      id: '10',
      title: 'Level Up RN',
      type: 'YouTube',
      author: 'Cathy Parkes',
      description: 'Flashcard style review. Short, punchy videos that give you ONLY what you need to know.',
      link: 'https://www.youtube.com/c/LevelUpRN',
      recommendedFor: 'Quick Review',
      tags: ['MedSurg', 'Maternity'],
      price: "Free",
      bestPhase: 'Phase 4: Review',
      studyStrategy: "Use this for 'Cramming'. \n\n1. If you forget 'Addison's Disease', watch her 4-minute video.\n2. Listen for her 'Cool Chicken' hints (Memory tricks).\n3. Great for Maternity and Pediatric milestones.",
      warning: "Not detailed enough for deep learning. Use only for review."
    },
    {
      id: '5',
      title: 'Archer Review',
      type: 'QBank',
      description: 'The budget-friendly alternative to UWorld. Questions are vague, similar to the real NCLEX.',
      link: 'https://archerreview.com/nclex-rn',
      recommendedFor: 'Budget Friendly',
      tags: ['Assessment', 'Vague Questions'],
      price: "$89 USD (~10k BDT)",
      bestPhase: 'Phase 4: Review',
      studyStrategy: "Use Archer for their 'Readiness Assessments' (CAT Exams).\n\n1. Their rationales are weak compared to UWorld, so study with UWorld, test with Archer.\n2. If you get '4 High/Very High' streaks on readiness assessments, you are ready to book the exam.",
      warning: "The content videos are very long and dry. Stick to the QBank."
    },
    {
      id: '6',
      title: 'NCLEX High Yield',
      type: 'YouTube',
      description: 'Dr. Zeeshan focuses on "The Method" and how to break down hard questions.',
      link: 'https://www.youtube.com/@NCLEXHighYield',
      recommendedFor: 'Test Taking Skills',
      tags: ['Strategy', 'Free'],
      price: "Free (YouTube)",
      bestPhase: 'Phase 2: Strategy',
      studyStrategy: "Watch his 'The Method' video. It teaches you how to eliminate 2 wrong answers immediately. Focus on his 'ASK GRAPH' method for prioritization.",
      warning: "He is very concise. Good for review, bad for learning basics."
    }
  ];

  const filteredResources = filter === 'All' ? resources : resources.filter(r => r.type === filter);

  return (
    <div className="space-y-8 animate-fade-in pb-10">
      
      {/* 1. Strategy Section - The "Teacher" Part */}
      <StudyStrategy />

      {/* 2. FAST TRACK CHEAT SHEET */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 rounded-xl p-6 text-white shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold flex items-center">
                <Zap className="mr-2 text-yellow-400 fill-current" />
                Fast Track: Which Channel for What?
            </h3>
            <span className="text-xs bg-white/10 px-2 py-1 rounded text-slate-300">Expert's Pick</span>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white/5 hover:bg-white/10 p-3 rounded-lg border border-white/10 transition-colors cursor-pointer" onClick={() => window.open('https://www.youtube.com/c/SimpleNursing', '_blank')}>
                  <div className="flex items-center mb-2">
                     <div className="p-1.5 bg-blue-500/20 rounded text-blue-300 mr-2"><MonitorPlay size={14} /></div>
                     <span className="text-xs text-slate-400 uppercase font-bold">Pharm & Visuals</span>
                  </div>
                  <span className="text-sm font-bold text-white block">SimpleNursing</span>
                  <p className="text-[10px] text-slate-400 mt-1">Best for mnemonics.</p>
              </div>
              <div className="bg-white/5 hover:bg-white/10 p-3 rounded-lg border border-white/10 transition-colors cursor-pointer" onClick={() => window.open('https://www.youtube.com/user/RegisteredNurseRN', '_blank')}>
                  <div className="flex items-center mb-2">
                     <div className="p-1.5 bg-teal-500/20 rounded text-teal-300 mr-2"><Book size={14} /></div>
                     <span className="text-xs text-slate-400 uppercase font-bold">Fundamentals</span>
                  </div>
                  <span className="text-sm font-bold text-white block truncate" title="RegisteredNurseRN">RegisteredNurseRN</span>
                  <p className="text-[10px] text-slate-400 mt-1">Best for basics.</p>
              </div>
               <div className="bg-white/5 hover:bg-white/10 p-3 rounded-lg border border-white/10 transition-colors cursor-pointer" onClick={() => window.open('https://www.youtube.com/c/nexusnursing', '_blank')}>
                  <div className="flex items-center mb-2">
                     <div className="p-1.5 bg-purple-500/20 rounded text-purple-300 mr-2"><Headphones size={14} /></div>
                     <span className="text-xs text-slate-400 uppercase font-bold">Logic & Audio</span>
                  </div>
                  <span className="text-sm font-bold text-white block">Nexus Nursing</span>
                  <p className="text-[10px] text-slate-400 mt-1">Best for "Why".</p>
              </div>
               <div className="bg-white/5 hover:bg-white/10 p-3 rounded-lg border border-white/10 transition-colors cursor-pointer" onClick={() => window.open('https://www.youtube.com/c/NCLEXCrusadeInternational', '_blank')}>
                  <div className="flex items-center mb-2">
                     <div className="p-1.5 bg-orange-500/20 rounded text-orange-300 mr-2"><Globe size={14} /></div>
                     <span className="text-xs text-slate-400 uppercase font-bold">ESL Students</span>
                  </div>
                  <span className="text-sm font-bold text-white block">NCLEX Crusade</span>
                  <p className="text-[10px] text-slate-400 mt-1">Best for English.</p>
              </div>
          </div>
      </div>

      {/* 3. Bangladeshi Student Hack Sidebar (Mobile: Stacked, Desktop: Sidebar layout) */}
      <div className="flex flex-col xl:flex-row gap-6">
        
        {/* Main Resource List */}
        <div className="flex-1 space-y-6">
            <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-slate-800 flex items-center">
                    <Book className="mr-2 text-teal-600" /> Full Resource Library
                </h2>
                {/* Filter */}
                <div className="flex gap-1 bg-slate-100 p-1 rounded-lg">
                    {['All', 'Book', 'YouTube', 'QBank'].map((type) => (
                        <button
                            key={type}
                            onClick={() => setFilter(type as any)}
                            className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${filter === type ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                        >
                            {type}
                        </button>
                    ))}
                </div>
            </div>

            <div className="space-y-4">
                {filteredResources.map((resource) => {
                    const isExpanded = expandedResource === resource.id;
                    return (
                        <div key={resource.id} className={`bg-white rounded-xl border transition-all duration-300 ${isExpanded ? 'border-teal-500 shadow-md ring-1 ring-teal-500' : 'border-slate-200 hover:border-teal-300 hover:shadow-sm'}`}>
                            {/* Card Header (Clickable) */}
                            <div 
                                className="p-4 cursor-pointer flex flex-col sm:flex-row gap-4"
                                onClick={() => setExpandedResource(isExpanded ? null : resource.id)}
                            >
                                {/* Icon Box */}
                                <div className={`w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0 ${
                                    resource.type === 'Book' ? 'bg-blue-100 text-blue-600' : 
                                    resource.type === 'YouTube' ? 'bg-red-100 text-red-600' : 
                                    'bg-purple-100 text-purple-600'
                                }`}>
                                    {resource.type === 'Book' && <Book size={24} />}
                                    {resource.type === 'YouTube' && <Youtube size={24} />}
                                    {resource.type === 'QBank' && <Globe size={24} />}
                                </div>

                                <div className="flex-1">
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <h3 className="font-bold text-slate-800 text-base">{resource.title}</h3>
                                            <div className="flex items-center gap-2 mt-1">
                                                <span className="text-xs text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">{resource.type}</span>
                                                <span className="text-xs text-slate-500">By {resource.author || "Various"}</span>
                                            </div>
                                        </div>
                                        <div className="text-right">
                                           {isExpanded ? <ChevronUp className="text-slate-400" /> : <ChevronDown className="text-slate-400" />}
                                        </div>
                                    </div>
                                    
                                    {!isExpanded && (
                                        <p className="text-sm text-slate-600 mt-2 line-clamp-2">{resource.description}</p>
                                    )}
                                </div>
                            </div>

                            {/* Expanded Content (Deep Dive) */}
                            {isExpanded && (
                                <div className="px-4 pb-4 sm:px-6 sm:pb-6 border-t border-slate-100 animate-fade-in">
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                                        
                                        {/* Left Column: Details */}
                                        <div className="space-y-4">
                                            <div>
                                                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Description</h4>
                                                <p className="text-sm text-slate-700 leading-relaxed">{resource.description}</p>
                                            </div>
                                            <div className="flex items-center gap-4">
                                                <div className="bg-slate-50 px-3 py-2 rounded-lg border border-slate-200">
                                                    <span className="block text-[10px] text-slate-400 uppercase font-bold">Best For</span>
                                                    <span className="text-sm font-semibold text-slate-700">{resource.recommendedFor}</span>
                                                </div>
                                                <div className="bg-slate-50 px-3 py-2 rounded-lg border border-slate-200">
                                                    <span className="block text-[10px] text-slate-400 uppercase font-bold">Est. Cost</span>
                                                    <span className="text-sm font-semibold text-slate-700">{resource.price}</span>
                                                </div>
                                            </div>
                                            <div>
                                                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Ideal Study Phase</h4>
                                                <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-bold border ${
                                                    resource.bestPhase.includes('Content') ? 'bg-blue-50 text-blue-700 border-blue-200' :
                                                    resource.bestPhase.includes('Strategy') ? 'bg-amber-50 text-amber-700 border-amber-200' :
                                                    'bg-teal-50 text-teal-700 border-teal-200'
                                                }`}>
                                                    <Star size={12} className="mr-1 fill-current" /> {resource.bestPhase}
                                                </span>
                                            </div>
                                        </div>

                                        {/* Right Column: Expert Strategy */}
                                        <div className="bg-teal-50/50 p-4 rounded-xl border border-teal-100">
                                            <h4 className="text-sm font-bold text-teal-800 flex items-center mb-3">
                                                <Info size={16} className="mr-2" />
                                                How to Study (Expert Guide)
                                            </h4>
                                            <div className="prose prose-sm prose-teal text-slate-700 text-sm leading-relaxed whitespace-pre-line">
                                                {resource.studyStrategy}
                                            </div>
                                            
                                            {resource.warning && (
                                                <div className="mt-4 flex items-start gap-2 bg-red-50 p-3 rounded-lg border border-red-100">
                                                    <AlertTriangle size={16} className="text-red-600 flex-shrink-0 mt-0.5" />
                                                    <p className="text-xs text-red-700"><strong>Warning:</strong> {resource.warning}</p>
                                                </div>
                                            )}

                                            <div className="mt-4 pt-4 border-t border-teal-100">
                                                <a 
                                                    href={resource.link} 
                                                    target="_blank" 
                                                    rel="noopener noreferrer"
                                                    className="w-full flex items-center justify-center px-4 py-2 bg-teal-600 text-white text-sm font-bold rounded-lg hover:bg-teal-700 transition-colors"
                                                >
                                                    <ExternalLink size={16} className="mr-2" /> Access Resource
                                                </a>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            )}
                        </div>
                    );
                })}
            </div>
        </div>

        {/* Sidebar Info (Desktop) / Bottom Info (Mobile) */}
        <div className="xl:w-80 space-y-6">
            
            {/* Where to Buy Card */}
            <div className="bg-slate-900 text-white p-6 rounded-xl shadow-lg">
                <h3 className="font-bold text-lg mb-3 flex items-center">
                    <MapPin className="mr-2 text-teal-400" />
                    Where to buy in BD?
                </h3>
                <div className="space-y-4 text-sm text-slate-300">
                    <div className="border-l-2 border-teal-500 pl-3">
                        <strong className="text-white block">Nilkhet Book Market</strong>
                        <p className="text-xs mt-1">Ask for "Medical Books" section. You can find high-quality reprints of Saunders & Mosbys for ~1200 BDT. Much cheaper than importing.</p>
                    </div>
                    <div className="border-l-2 border-teal-500 pl-3">
                        <strong className="text-white block">Facebook Groups</strong>
                        <p className="text-xs mt-1">Join "NCLEX RN Bangladesh" groups. Seniors often sell their used books and share UWorld accounts (Group Buy).</p>
                    </div>
                </div>
            </div>

            {/* Cost Saving Tip */}
            <div className="bg-emerald-50 p-5 rounded-xl border border-emerald-100">
                <h3 className="font-bold text-emerald-800 text-sm flex items-center mb-2">
                    <ShoppingCart size={16} className="mr-2" />
                    Cost Saving Hack
                </h3>
                <p className="text-xs text-emerald-700 leading-relaxed">
                    <strong>UWorld Group Buy:</strong> UWorld allows 1 active session. Find a study partner who studies at night while you study in the day. Split the $169 cost (8k BDT each).
                </p>
            </div>

            {/* Warning Card */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
                <h3 className="font-bold text-slate-800 text-sm flex items-center mb-2">
                    <AlertCircle size={16} className="mr-2 text-red-500" />
                    Avoid These Traps
                </h3>
                <ul className="text-xs text-slate-600 space-y-2 list-disc list-inside">
                    <li>Don't buy 5 different books. Stick to <strong>One Content Book</strong> (Saunders) and <strong>One QBank</strong> (UWorld).</li>
                    <li>Avoid random YouTube channels. Stick to verified ones like SimpleNursing or RegisteredNurseRN.</li>
                    <li>Don't start QBank until you finish at least 50% of content review.</li>
                </ul>
            </div>

        </div>
      </div>
    </div>
  );
};

export default Resources;