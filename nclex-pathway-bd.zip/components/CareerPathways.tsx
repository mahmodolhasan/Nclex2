import React from 'react';
import { CareerPath } from '../types';
import { Plane, Building2, AlertTriangle, CheckCircle2 } from 'lucide-react';

const CareerPathways: React.FC = () => {
  const paths: CareerPath[] = [
    {
      id: 'usa',
      country: 'Direct to USA',
      pros: [
        'Highest salary globally ($60k - $100k+ / year)',
        'Green Card opportunity (EB-3 Visa) for family',
        'Strong career growth & specialization',
        '3-day work week (usually 12hr shifts)'
      ],
      cons: [
        'Long processing time (1.5 - 3 years currently)',
        'Requires passing NCLEX + IELTS/PTE',
        'Strict strict visa screening'
      ],
      risks: [
        'Visa retrogression (waiting times can increase)',
        'Need recent bedside experience (some states require it)'
      ],
      timeline: '2 - 3 Years',
      cost: '$$$ (Exam fees, VisaScreen, Travel)'
    },
    {
      id: 'canada',
      country: 'Direct to Canada',
      pros: [
        'High quality of life & safety',
        'Permanent Residency (PR) friendly',
        'Excellent healthcare benefits'
      ],
      cons: [
        'NNAS process is notoriously slow and strict',
        'Often requires extra education/bridging courses',
        'Very expensive licensing process',
        'High cost of living & taxes'
      ],
      risks: [
        'Might not get full RN license immediately (might start as LPN/RPN)',
        'Complex provincial regulations'
      ],
      timeline: '2 - 4 Years',
      cost: '$$$$'
    },
    {
      id: 'middle-east',
      country: 'Middle East First (Dubai/Saudi)',
      pros: [
        'Tax-free income (save money for US/Canada)',
        'Easier to enter (DHA/HAAD/Prometric exams are easier than NCLEX)',
        'Gains you international acute care experience',
        'Faster processing (3-6 months)'
      ],
      cons: [
        'Lower salary compared to West',
        'Contract based (usually no permanent residency)',
        'Work culture can be demanding',
        'Six-day work weeks are common'
      ],
      risks: [
        'Gap in "Western" standard education',
        'Might get "stuck" in the comfort zone and delay NCLEX'
      ],
      timeline: '6 Months to Start',
      cost: '$$'
    }
  ];

  return (
    <div className="space-y-8">
      <div className="bg-white p-8 rounded-xl shadow-sm border border-slate-100">
        <h2 className="text-2xl font-bold text-slate-800 mb-4">The Strategic Dilemma</h2>
        <p className="text-slate-600 leading-relaxed">
          As a Bangladeshi student, you face a common choice. <strong>Direct migration</strong> is the gold standard but takes time. The <strong>Middle East route</strong> acts as a stepping stone to gain experience and money while the US process runs in the background.
          <br /><br />
          <span className="font-semibold text-teal-700">Recommendation:</span> If you can afford to wait 2 years after graduation in Bangladesh while working at a reputable hospital (e.g., Square, Apollo, United) and preparing for NCLEX, go <span className="font-bold">Direct to USA</span>. If you need immediate money or cannot find a job in a tertiary hospital in BD, go to the Middle East.
        </p>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {paths.map((path) => (
          <div key={path.id} className="bg-white rounded-xl shadow-sm border border-slate-100 flex flex-col h-full">
            <div className={`p-6 ${path.id === 'usa' ? 'bg-blue-50' : path.id === 'canada' ? 'bg-red-50' : 'bg-emerald-50'} rounded-t-xl border-b border-slate-100`}>
              <div className="flex items-center justify-between mb-2">
                 {path.id === 'usa' || path.id === 'canada' ? <Plane className="text-slate-700" /> : <Building2 className="text-slate-700" />}
                 <span className="font-bold text-sm text-slate-500">{path.cost}</span>
              </div>
              <h3 className="text-xl font-bold text-slate-800">{path.country}</h3>
              <span className="text-xs font-semibold bg-white px-2 py-1 rounded text-slate-600 mt-2 inline-block shadow-sm">
                Timeline: {path.timeline}
              </span>
            </div>

            <div className="p-6 flex-1 space-y-6">
              <div>
                <h4 className="flex items-center text-sm font-bold text-green-700 mb-3 uppercase tracking-wider">
                  <CheckCircle2 size={16} className="mr-2" /> Pros
                </h4>
                <ul className="space-y-2">
                  {path.pros.map((pro, i) => (
                    <li key={i} className="text-sm text-slate-600 flex items-start">
                      <span className="mr-2">•</span> {pro}
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h4 className="flex items-center text-sm font-bold text-orange-600 mb-3 uppercase tracking-wider">
                   <AlertTriangle size={16} className="mr-2" /> Cons
                </h4>
                <ul className="space-y-2">
                  {path.cons.map((con, i) => (
                    <li key={i} className="text-sm text-slate-600 flex items-start">
                      <span className="mr-2">•</span> {con}
                    </li>
                  ))}
                </ul>
              </div>

               <div>
                <h4 className="flex items-center text-sm font-bold text-red-600 mb-3 uppercase tracking-wider">
                   Risk Factors
                </h4>
                <ul className="space-y-2">
                  {path.risks.map((risk, i) => (
                    <li key={i} className="text-sm text-slate-600 flex items-start">
                      <span className="mr-2">•</span> {risk}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CareerPathways;