import React from 'react';
import { View } from '../types';
import { LayoutDashboard, Map, BookOpen, Compass, MessageSquare, FileText } from 'lucide-react';

interface MobileNavProps {
  currentView: View;
  onNavigate: (view: View) => void;
}

const MobileNav: React.FC<MobileNavProps> = ({ currentView, onNavigate }) => {
  const navItems = [
    { id: 'dashboard', label: 'Home', icon: LayoutDashboard },
    { id: 'roadmap', label: 'Roadmap', icon: Map },
    { id: 'syllabus', label: 'Syllabus', icon: FileText },
    { id: 'resources', label: 'Study', icon: BookOpen },
    { id: 'pathways', label: 'Paths', icon: Compass },
    { id: 'mentor', label: 'Mentor', icon: MessageSquare },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 pb-safe lg:hidden z-50">
      <div className="flex justify-around items-center px-2 py-2">
        {navItems.map((item) => {
          const isActive = currentView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id as View)}
              className={`flex flex-col items-center justify-center p-2 w-full transition-colors ${
                isActive ? 'text-teal-600' : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              <item.icon size={20} className={`mb-1 ${isActive ? 'fill-current' : ''}`} strokeWidth={isActive ? 2.5 : 2} />
              <span className="text-[10px] font-medium">{item.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default MobileNav;