import React, { useState } from 'react';
import { Database, FileCheck, Stethoscope, Briefcase, AlertTriangle, CheckCircle, ExternalLink, Coins, MapPin, Clock, DollarSign, BookOpen, Globe, Youtube } from 'lucide-react';

const MiddleEastGuide: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'overview' | 'dha' | 'haad' | 'moh'>('overview');

  const tabs = [
    { id: 'overview', label: 'Overview & Salary' },
    { id: 'dha', label: 'DHA (Dubai)' },
    { id: 'haad', label: 'HAAD (Abu Dhabi)' },
    { id: 'moh', label: 'Saudi / MOH' },
  ];

  const renderOverview = () => (
    <div className="space-y-8 animate-fade-in">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {[
          { id: 'dha', name: 'DHA (Dubai)', color: 'blue', desc: 'Best for lifestyle. Exam: Prometric.' },
          { id: 'haad', name: 'HAAD/DOH (Abu Dhabi)', color: 'teal', desc: 'Strict process. Exam: Pearson Vue.' },
          { id: 'moh', name: 'MOH / Saudi', color: 'green', desc: 'Higher savings. Exam: Prometric.' }
        ].map((r) => (
          <button 
            key={r.id} 
            onClick={() => setActiveTab(r.id as any)}
            className={`bg-white p-4 rounded-xl border border-${r.color}-100 shadow-sm hover:border-${r.color}-300 hover:shadow-md transition-all text-left`}
          >
            <h3 className={`text-lg font-bold text-${r.color}-700 mb-1`}>{r.name}</h3>
            <p className="text-xs text-slate-500">{r.desc}</p>
            <div className="mt-3 text-xs font-semibold text-slate-400 flex items-center">
                Click for details <ExternalLink size={10} className="ml-1" />
            </div>
          </button>
        ))}
      </div>

      <div className="bg-white p-6 rounded-xl border border-slate-100 shadow-sm">
          <h3 className="font-bold text-slate-800 flex items-center mb-4">
              <Coins size={20} className="mr-2 text-teal-600" />
              Salary & Savings Insight
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-slate-50 p-4 rounded-lg">
                  <h4 className="text-sm font-bold text-slate-500 uppercase mb-2">Bangladesh (Private)</h4>
                  <div className="flex items-baseline">
                      <span className="text-2xl font-bold text-slate-800">15k - 25k</span>
                      <span className="text-xs text-slate-500 ml-1">BDT/month</span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">Entry level staff nurse</p>
              </div>
              <div className="bg-teal-50 p-4 rounded-lg border border-teal-100">
                  <h4 className="text-sm font-bold text-teal-600 uppercase mb-2">Middle East (Avg)</h4>
                  <div className="flex items-baseline">
                      <span className="text-2xl font-bold text-teal-800">80k - 1.2 Lac</span>
                      <span className="text-xs text-teal-600 ml-1">BDT/month</span>
                  </div>
                  <p className="text-xs text-teal-600 mt-1">Tax-free income + Accommodation</p>
              </div>
          </div>
      </div>

      <div className="bg-amber-50 border-l-4 border-amber-500 p-5 rounded-r-lg">
        <div className="flex items-start">
            <AlertTriangle className="text-amber-600 mr-3 mt-1 flex-shrink-0" size={20} />
            <div>
                <h4 className="font-bold text-amber-800">Experience Requirement</h4>
                <p className="text-amber-700 text-sm mt-1">
                    Most Middle East authorities require <strong>2 years of post-registration clinical experience</strong>. The gap between your experience and application cannot exceed 6-12 months.
                </p>
            </div>
        </div>
      </div>
    </div>
  );

  const renderDetail = (
    title: string, 
    portalName: string, 
    portalLink: string, 
    examType: string, 
    steps: any[], 
    examDetails: any,
    costs: any[]
  ) => (
    <div className="space-y-6 animate-fade-in">
        <div className="flex flex-col md:flex-row md:items-center justify-between bg-white p-6 rounded-xl border border-slate-100 shadow-sm gap-4">
            <div>
                <h2 className="text-2xl font-bold text-slate-800">{title}</h2>
                <div className="flex flex-wrap gap-2 mt-2">
                    <span className="px-2 py-1 bg-blue-50 text-blue-700 rounded text-xs font-semibold border border-blue-100">Exam: {examType}</span>
                    <span className="px-2 py-1 bg-teal-50 text-teal-700 rounded text-xs font-semibold border border-teal-100">Exp: 2 Years</span>
                </div>
            </div>
            <a 
                href={portalLink} 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center justify-center px-4 py-2 bg-slate-900 text-white rounded-lg font-medium hover:bg-slate-800 transition-colors text-sm"
            >
                Visit {portalName} <ExternalLink size={16} className="ml-2" />
            </a>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Process Steps */}
            <div className="lg:col-span-2 space-y-6">
                <h3 className="text-lg font-bold text-slate-800 flex items-center">
                    <FileCheck size={20} className="mr-2 text-teal-600" /> Application Process
                </h3>
                <div className="relative border-l-2 border-slate-200 ml-3 space-y-8 pb-2">
                    {steps.map((step, idx) => (
                        <div key={idx} className="relative pl-8">
                            <div className="absolute -left-[9px] top-0 h-4 w-4 rounded-full bg-white border-2 border-teal-500"></div>
                            <h4 className="font-bold text-slate-800 text-sm md:text-base">{step.title}</h4>
                            <p className="text-xs md:text-sm text-slate-600 mt-1 mb-2">{step.desc}</p>
                            {step.videoQuery && (
                                <a 
                                    href={`https://www.youtube.com/results?search_query=${encodeURIComponent(step.videoQuery)}`}
                                    target="_blank"
                                    rel="noopener noreferrer" 
                                    className="inline-flex items-center text-xs text-red-600 hover:bg-red-50 px-2 py-1 rounded transition-colors border border-red-100"
                                >
                                    <Youtube size={12} className="mr-1" /> Watch Tutorial
                                </a>
                            )}
                        </div>
                    ))}
                </div>
            </div>

            {/* Sidebar: Cost & Exam Pattern */}
            <div className="space-y-6">
                {/* Exam Pattern */}
                <div className="bg-white p-5 rounded-xl border border-slate-100 shadow-sm">
                    <h3 className="text-sm font-bold text-slate-800 flex items-center mb-4 border-b border-slate-100 pb-2">
                        <BookOpen size={16} className="mr-2 text-blue-600" /> Exam Pattern
                    </h3>
                    <div className="space-y-3 text-sm">
                        <div className="flex justify-between">
                            <span className="text-slate-500">Questions</span>
                            <span className="font-medium text-slate-800">{examDetails.questions} MCQs</span>
                        </div>
                        <div className="flex justify-between">
                            <span className="text-slate-500">Duration</span>
                            <span className="font-medium text-slate-800">{examDetails.time}</span>
                        </div>
                        <div className="flex justify-between">
                            <span className="text-slate-500">Passing</span>
                            <span className="font-medium text-green-600">{examDetails.passing}</span>
                        </div>
                        <div className="flex justify-between">
                            <span className="text-slate-500">Attempts</span>
                            <span className="font-medium text-slate-800">{examDetails.attempts} per year</span>
                        </div>
                    </div>
                </div>

                {/* Costs */}
                <div className="bg-white p-5 rounded-xl border border-slate-100 shadow-sm">
                    <h3 className="text-sm font-bold text-slate-800 flex items-center mb-4 border-b border-slate-100 pb-2">
                        <DollarSign size={16} className="mr-2 text-green-600" /> Estimated Costs
                    </h3>
                    <div className="space-y-3">
                        {costs.map((cost, idx) => (
                            <div key={idx} className="flex justify-between items-center text-sm">
                                <span className="text-slate-500">{cost.item}</span>
                                <div className="text-right">
                                    <div className="font-medium text-slate-800">{cost.foreign}</div>
                                    <div className="text-[10px] text-slate-400">~{cost.bdt}</div>
                                </div>
                            </div>
                        ))}
                        <div className="pt-2 mt-2 border-t border-slate-100 text-xs text-slate-400 italic text-center">
                            *Excludes travel & visa costs
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  );

  return (
    <div className="space-y-6">
        {/* Tab Header */}
        <div className="flex overflow-x-auto pb-2 gap-2 scrollbar-hide">
            {tabs.map(tab => (
                <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`whitespace-nowrap px-4 py-2 rounded-lg text-sm font-bold transition-all ${
                        activeTab === tab.id 
                        ? 'bg-slate-800 text-white shadow-md' 
                        : 'bg-white text-slate-500 hover:bg-slate-50 border border-slate-200'
                    }`}
                >
                    {tab.label}
                </button>
            ))}
        </div>

        {/* Tab Content */}
        {activeTab === 'overview' && renderOverview()}
        
        {activeTab === 'dha' && renderDetail(
            "Dubai Health Authority (DHA)",
            "Sheryan Portal",
            "https://services.dha.gov.ae/sheryan/online/",
            "Prometric (CBT)",
            [
                { title: "Self Assessment", desc: "Use the Sheryan self-assessment tool to check eligibility before paying anything.", videoQuery: "dha sheryan self assessment for nurses" },
                { title: "Dataflow Verification", desc: "Upload Degree, License, and Experience letters. Dataflow checks authenticity directly with your college/hospital.", videoQuery: "how to apply dataflow for dha nursing" },
                { title: "Sheryan ID & CBT Booking", desc: "Once Dataflow is done, generate Sheryan ID and book your Prometric exam.", videoQuery: "book dha prometric exam bangladesh" },
                { title: "Take Exam", desc: "Center available in Dhaka (Gulshan). Result usually within 2-5 days." },
                { title: "Eligibility Letter", desc: "If passed, you get an Eligibility Letter valid for 1 year to find a job." }
            ],
            { questions: "150", time: "165 Mins", passing: "60%", attempts: "3" },
            [
                { item: "Application", foreign: "220 AED", bdt: "7,500 BDT" },
                { item: "Dataflow", foreign: "1200 AED", bdt: "40,000 BDT" },
                { item: "Prometric Exam", foreign: "$240 USD", bdt: "28,000 BDT" },
                { item: "Total Est.", foreign: "-", bdt: "75k - 80k BDT" }
            ]
        )}

        {activeTab === 'haad' && renderDetail(
            "Dept of Health Abu Dhabi (HAAD/DOH)",
            "TAMM Portal",
            "https://www.tamm.abudhabi/en",
            "Pearson Vue",
            [
                { title: "Dataflow First", desc: "Unlike DHA, HAAD often requires Dataflow to be initiated first via the Dataflow website directly." },
                { title: "Create TAMM Account", desc: "This is the unified Abu Dhabi gov portal. All credentialing happens here.", videoQuery: "create tamm account for haad exam" },
                { title: "Pearson Vue Booking", desc: "HAAD exams are often conducted via Pearson Vue, similar to NCLEX style but simpler.", videoQuery: "haad pearson vue booking nursing" },
                { title: "Pass & Job Hunt", desc: "Passing score varies by specialty but usually 60-65%." }
            ],
            { questions: "150", time: "180 Mins", passing: "Variable", attempts: "3" },
            [
                 { item: "Application", foreign: "100 AED", bdt: "3,500 BDT" },
                 { item: "Dataflow", foreign: "1200 AED", bdt: "40,000 BDT" },
                 { item: "Exam Fee", foreign: "$200 USD", bdt: "24,000 BDT" },
                 { item: "Total Est.", foreign: "-", bdt: "70k - 75k BDT" }
            ]
        )}

        {activeTab === 'moh' && renderDetail(
            "Saudi Arabia (MOH) / SCFHS",
            "Mumaris Plus",
            "https://portal.scfhs.org.sa/",
            "Prometric",
            [
                { title: "Professional Classification", desc: "Create account on Mumaris Plus. Upload docs for 'Classification'.", videoQuery: "mumaris plus account creation nursing" },
                { title: "Dataflow", desc: "Saudi Dataflow is mandatory. Strict on experience verification.", videoQuery: "saudi dataflow process for nurses" },
                { title: "Eligibility Number", desc: "Once classified, you get an eligibility number to book Prometric." },
                { title: "Prometric Exam", desc: "Book via Prometric website using the eligibility ID.", videoQuery: "saudi prometric exam booking" }
            ],
            { questions: "150", time: "180 Mins", passing: "60%", attempts: "Unlimited" },
            [
                 { item: "Classification", foreign: "200 SAR", bdt: "6,500 BDT" },
                 { item: "Dataflow", foreign: "1000 SAR", bdt: "32,000 BDT" },
                 { item: "Exam Fee", foreign: "$280 USD", bdt: "33,000 BDT" },
                 { item: "Total Est.", foreign: "-", bdt: "75k - 80k BDT" }
            ]
        )}
    </div>
  );
};

export default MiddleEastGuide;