import React, { useState } from 'react';
import { RoadmapStep } from '../types';
import { CheckCircle, Circle, Bell, Calendar, X, Map as MapIcon, Globe, Plane, Lightbulb, AlertTriangle } from 'lucide-react';
import NclexGuide from './NclexGuide';
import MiddleEastGuide from './MiddleEastGuide';

interface RoadmapProps {
  steps: RoadmapStep[];
  toggleTask: (stepId: string, taskId: string) => void;
  setReminder: (stepId: string, taskId: string, date: string | undefined) => void;
}

type Tab = 'tracker' | 'nclex' | 'middle-east';

const Roadmap: React.FC<RoadmapProps> = ({ steps, toggleTask, setReminder }) => {
  const [activeTab, setActiveTab] = useState<Tab>('tracker');
  const [editingReminder, setEditingReminder] = useState<{stepId: string, taskId: string} | null>(null);
  const [tempDate, setTempDate] = useState('');

  const handleOpenReminder = (stepId: string, taskId: string, currentDate?: string) => {
    setEditingReminder({ stepId, taskId });
    // Format current date for datetime-local input (YYYY-MM-DDTHH:mm)
    if (currentDate) {
        setTempDate(new Date(currentDate).toISOString().slice(0, 16));
    } else {
        setTempDate('');
    }
  };

  const handleSaveReminder = () => {
    if (editingReminder) {
      setReminder(editingReminder.stepId, editingReminder.taskId, tempDate ? new Date(tempDate).toISOString() : undefined);
      setEditingReminder(null);
      setTempDate('');
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-10 lg:pb-0">
      {/* Tab Navigation */}
      <div className="bg-white p-2 rounded-xl border border-slate-200 shadow-sm flex overflow-x-auto">
        <button
          onClick={() => setActiveTab('tracker')}
          className={`flex-1 flex items-center justify-center px-4 py-3 rounded-lg text-sm font-bold transition-all whitespace-nowrap ${
            activeTab === 'tracker' 
              ? 'bg-slate-900 text-white shadow-md' 
              : 'text-slate-500 hover:bg-slate-50'
          }`}
        >
          <MapIcon size={16} className="mr-2" />
          My Tracker
        </button>
        <button
          onClick={() => setActiveTab('nclex')}
          className={`flex-1 flex items-center justify-center px-4 py-3 rounded-lg text-sm font-bold transition-all whitespace-nowrap ${
            activeTab === 'nclex' 
              ? 'bg-blue-600 text-white shadow-md' 
              : 'text-slate-500 hover:bg-blue-50'
          }`}
        >
          <Globe size={16} className="mr-2" />
          NCLEX Guide
        </button>
        <button
          onClick={() => setActiveTab('middle-east')}
          className={`flex-1 flex items-center justify-center px-4 py-3 rounded-lg text-sm font-bold transition-all whitespace-nowrap ${
            activeTab === 'middle-east' 
              ? 'bg-teal-600 text-white shadow-md' 
              : 'text-slate-500 hover:bg-teal-50'
          }`}
        >
          <Plane size={16} className="mr-2" />
          Middle East
        </button>
      </div>

      {/* Content Area */}
      {activeTab === 'tracker' && (
        <div className="bg-white p-6 md:p-8 rounded-xl shadow-sm border border-slate-100 animate-fade-in">
          <h2 className="text-xl md:text-2xl font-bold text-slate-800 mb-2">Your Journey: From BD to RN</h2>
          <p className="text-sm md:text-base text-slate-500 mb-6">A strategic timeline optimized for a current 2nd-year student. Based on real success stories.</p>

          <div className="relative border-l-4 border-teal-100 ml-2 md:ml-4 space-y-10 md:space-y-12">
            {steps.map((step, index) => (
              <div key={step.id} className="relative pl-6 md:pl-8">
                {/* Timeline Dot */}
                <div className="absolute -left-[11px] md:-left-[14px] top-1 h-5 w-5 md:h-6 md:w-6 rounded-full bg-teal-500 border-4 border-white shadow-sm flex items-center justify-center">
                  <span className="sr-only">Step {index + 1}</span>
                </div>

                <div className="bg-slate-50 p-4 md:p-6 rounded-lg border border-slate-200 hover:shadow-md transition-shadow">
                  <div className="flex justify-between items-center mb-4">
                    <div>
                      <span className="text-xs font-bold tracking-wider text-teal-600 uppercase mb-1 block">
                        {step.year}
                      </span>
                      <h3 className="text-lg md:text-xl font-bold text-slate-800">{step.title}</h3>
                    </div>
                  </div>

                  {/* Mentor Tip Box */}
                  {step.mentorTip && (
                    <div className="mb-4 bg-amber-50 border border-amber-100 p-3 rounded-lg flex items-start gap-3">
                        <Lightbulb size={18} className="text-amber-500 mt-1 flex-shrink-0" />
                        <div>
                            <span className="block text-xs font-bold text-amber-700 uppercase">Expert Insight</span>
                            <p className="text-sm text-slate-700 leading-snug">{step.mentorTip}</p>
                        </div>
                    </div>
                  )}

                  {/* Warnings Box */}
                  {step.warnings && step.warnings.length > 0 && (
                      <div className="mb-4 px-3 py-2 bg-red-50 border border-red-100 rounded-lg">
                          <h5 className="text-xs font-bold text-red-700 flex items-center mb-1">
                              <AlertTriangle size={12} className="mr-1" /> Watch Out For:
                          </h5>
                          <ul className="list-disc list-inside text-xs text-slate-600">
                              {step.warnings.map((w, i) => (
                                  <li key={i}>{w}</li>
                              ))}
                          </ul>
                      </div>
                  )}

                  <div className="space-y-3">
                    {step.tasks.map((task) => {
                       const hasReminder = !!task.reminder;
                       const isOverdue = hasReminder && new Date(task.reminder!) < new Date();
                       const isEditing = editingReminder?.taskId === task.id;

                       return (
                      <div 
                        key={task.id} 
                        className={`flex flex-col p-3 rounded-lg transition-colors ${task.completed ? 'bg-teal-50/50' : 'bg-white hover:bg-slate-100 border border-slate-100'}`}
                      >
                        <div className="flex items-start justify-between w-full">
                            <div 
                              className="flex items-start space-x-3 cursor-pointer flex-1 py-1"
                              onClick={() => toggleTask(step.id, task.id)}
                            >
                              <button className="mt-0.5 flex-shrink-0 text-teal-600 focus:outline-none">
                                  {task.completed ? <CheckCircle size={20} className="fill-teal-100" /> : <Circle size={20} />}
                              </button>
                              <span className={`text-sm ${task.completed ? 'text-slate-500 line-through' : 'text-slate-700 font-medium'}`}>
                                  {task.text}
                              </span>
                            </div>
                            
                            <div className="flex items-center ml-2">
                                <button 
                                  onClick={() => handleOpenReminder(step.id, task.id, task.reminder)}
                                  className={`p-2 rounded-full transition-colors ${hasReminder ? (isOverdue ? 'text-red-500 bg-red-50' : 'text-teal-600 bg-teal-50') : 'text-slate-300 hover:text-slate-500 hover:bg-slate-200'}`}
                                  title={hasReminder ? new Date(task.reminder!).toLocaleString() : "Set Reminder"}
                                >
                                    <Bell size={18} className={hasReminder ? 'fill-current' : ''} />
                                </button>
                            </div>
                        </div>

                        {/* Reminder Display / Badge */}
                        {hasReminder && !isEditing && (
                            <div className={`mt-2 ml-8 text-xs flex items-center ${isOverdue ? 'text-red-600' : 'text-teal-600'}`}>
                                <Calendar size={12} className="mr-1" />
                                {new Date(task.reminder!).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })}
                                {isOverdue && <span className="ml-2 font-bold">(Overdue)</span>}
                            </div>
                        )}

                        {/* Reminder Editor */}
                        {isEditing && (
                            <div className="mt-3 ml-0 md:ml-8 p-3 bg-slate-50 rounded-lg border border-slate-200 animate-fade-in">
                                <label className="block text-xs font-bold text-slate-500 mb-1">Set Study Reminder</label>
                                <div className="flex flex-col sm:flex-row gap-2">
                                    <input 
                                      type="datetime-local" 
                                      value={tempDate}
                                      onChange={(e) => setTempDate(e.target.value)}
                                      className="flex-1 text-xs p-2 border border-slate-300 rounded focus:outline-none focus:border-teal-500 bg-white"
                                    />
                                    <div className="flex gap-2">
                                      <button 
                                          onClick={handleSaveReminder}
                                          className="flex-1 sm:flex-none px-3 py-2 bg-teal-600 text-white text-xs rounded font-medium hover:bg-teal-700"
                                      >
                                          Save
                                      </button>
                                      <button 
                                          onClick={() => {
                                              setReminder(step.id, task.id, undefined); // Clear reminder
                                              setEditingReminder(null);
                                          }}
                                          className="flex-1 sm:flex-none px-3 py-2 bg-white border border-red-200 text-red-500 text-xs rounded font-medium hover:bg-red-50"
                                      >
                                          Clear
                                      </button>
                                      <button 
                                          onClick={() => setEditingReminder(null)}
                                          className="px-2 text-slate-400 hover:text-slate-600"
                                      >
                                          <X size={16} />
                                      </button>
                                    </div>
                                </div>
                            </div>
                        )}
                      </div>
                    )})}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'nclex' && <NclexGuide />}
      {activeTab === 'middle-east' && <MiddleEastGuide />}

    </div>
  );
};

export default Roadmap;