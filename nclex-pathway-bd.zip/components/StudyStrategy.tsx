import React from 'react';
import { Layers, Brain, Target, Flag, ArrowRight, Lightbulb, Clock, AlertOctagon } from 'lucide-react';

const StudyStrategy: React.FC = () => {
  const phases = [
    {
      id: 1,
      title: "Content Mastery",
      subtitle: "Build the Foundation",
      duration: "Months 1-3",
      icon: Layers,
      color: "bg-blue-100 text-blue-700",
      border: "border-blue-200",
      tools: ["Saunders (Book)", "SimpleNursing (Pharm)", "RegisteredNurseRN (Fundies)"],
      desc: "Do not touch a QBank yet. If you don't know Heart Failure pathophysiology, no amount of guessing will help. Focus on 'Systems'.",
      action: "Read 1 Chapter of Saunders. Watch matching video. Teach it to a friend (Feynman Technique).",
      routine: "2 Hours/Day: 1.5h Reading, 30m Video."
    },
    {
      id: 2,
      title: "Strategy & Methodology",
      subtitle: "Learn How to Answer",
      duration: "Month 4",
      icon: Brain,
      color: "bg-amber-100 text-amber-700",
      border: "border-amber-200",
      tools: ["Mark Klimek (Audio)", "NCLEX Crusade (7 Day Training)"],
      desc: "NCLEX is 50% knowledge and 50% logic. Learn 'Prioritization' (Acute vs Chronic) and 'Delegation' rules now.",
      action: "Listen to Mark K Lecture 12 five times. Watch NCLEX Crusade 'Day 1' to fix your English parsing logic.",
      routine: "Audio while commuting. Videos on weekends."
    },
    {
      id: 3,
      title: "The Grind (Application)",
      subtitle: "QBank Mastery",
      duration: "Months 5-6",
      icon: Target,
      color: "bg-teal-100 text-teal-700",
      border: "border-teal-200",
      tools: ["UWorld (Primary)", "Nexus Nursing (YouTube)"],
      desc: "The goal is NOT a high score. The goal is reading the RATIONALE. Why is 'A' wrong? Why is 'B' right?",
      action: "75 Questions/Day. Timed Mode. Tutor Mode OFF. Read every single word of the explanation.",
      routine: "Morning: Test. Evening: Review Rationales."
    },
    {
      id: 4,
      title: "Simulation & Speed",
      subtitle: "Exam Mode",
      duration: "Month 7",
      icon: Flag,
      color: "bg-indigo-100 text-indigo-700",
      border: "border-indigo-200",
      tools: ["Archer (CAT Exams)", "Readiness Assessments"],
      desc: "Build stamina. Sitting for 5 hours is physical. Train your brain to focus without breaks.",
      action: "Take 1 CAT Exam every 3 days. Review weak areas on off days. Stop studying 2 days before exam.",
      routine: "Full simulation: 8 AM to 1 PM (No phone)."
    }
  ];

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 animate-fade-in">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-slate-900 text-white rounded-lg">
           <Brain size={24} />
        </div>
        <div>
           <h2 className="text-xl font-bold text-slate-800">The "Pyramid of Success" Masterclass</h2>
           <p className="text-sm text-slate-500">Don't study randomly. Follow this expert-proven strict order.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 relative">
         {/* Connector Line (Desktop) */}
         <div className="hidden xl:block absolute top-12 left-0 right-0 h-0.5 bg-slate-100 -z-10 translate-y-4"></div>

         {phases.map((phase, idx) => (
           <div key={idx} className={`relative bg-white p-5 rounded-xl border-2 ${phase.border} shadow-sm hover:shadow-md transition-all flex flex-col h-full`}>
              <div className={`inline-flex items-center justify-center p-2 rounded-full ${phase.color} mb-3 self-start`}>
                 <phase.icon size={20} />
              </div>
              <div className="absolute top-5 right-5 text-xs font-bold text-slate-400 uppercase tracking-wider">Step {phase.id}</div>
              
              <h3 className="font-bold text-lg text-slate-800">{phase.title}</h3>
              <p className="text-xs font-semibold text-slate-500 mb-3">{phase.subtitle} ({phase.duration})</p>
              
              <p className="text-xs text-slate-600 leading-relaxed mb-4 min-h-[50px]">{phase.desc}</p>
              
              <div className="mt-auto space-y-2">
                  <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                    <h4 className="text-[10px] font-bold text-slate-500 uppercase mb-1 flex items-center">
                        <Lightbulb size={10} className="mr-1 text-amber-500" /> Action
                    </h4>
                    <p className="text-xs text-slate-700 font-medium leading-tight">{phase.action}</p>
                  </div>
                  
                  <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                    <h4 className="text-[10px] font-bold text-slate-500 uppercase mb-1 flex items-center">
                        <Clock size={10} className="mr-1 text-teal-500" /> Daily Routine
                    </h4>
                    <p className="text-xs text-slate-700 font-medium leading-tight">{phase.routine}</p>
                  </div>
              </div>
           </div>
         ))}
      </div>
    </div>
  );
};

export default StudyStrategy;