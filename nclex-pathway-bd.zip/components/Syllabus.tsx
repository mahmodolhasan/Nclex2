import React, { useState } from 'react';
import { Activity, ShieldCheck, HeartPulse, Stethoscope, Video, ExternalLink, BookOpen, AlertCircle, Sparkles, X, ChevronDown, ChevronUp, Globe, Plane, Lightbulb, Target, Youtube, PlayCircle, Syringe, Brain, Baby, Bone } from 'lucide-react';
import { explainNclexTopic } from '../services/gemini';

const Syllabus: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'nclex' | 'middleEast'>('nclex');
  const [expandedSection, setExpandedSection] = useState<number | null>(0);
  const [selectedTopic, setSelectedTopic] = useState<string | null>(null);
  const [aiExplanation, setAiExplanation] = useState<string>('');
  const [loadingAi, setLoadingAi] = useState(false);

  const handleExplain = async (topic: string) => {
      setSelectedTopic(topic);
      setLoadingAi(true);
      setAiExplanation('');
      const text = await explainNclexTopic(topic);
      setAiExplanation(text);
      setLoadingAi(false);
  };

  const nclexDeepDive = [
    {
      category: 'Safe and Effective Care Environment',
      subcategory: 'Management of Care',
      percentage: '17-23%',
      icon: ShieldCheck,
      color: 'text-blue-600',
      bg: 'bg-blue-50',
      borderColor: 'border-blue-100',
      desc: 'The largest section. Focuses on nursing laws, ethics, and leadership.',
      expertTip: 'Delegation is the #1 topic here. RN eats (Evaluate, Assess, Teach). LPN does sterile procedures/meds (stable). UAP does ADLs/Vitals (stable).',
      pitfall: 'Thinking you can delegate "Assessment" or "Teaching" to an LPN. Never.',
      topics: [
        { name: 'Advanced Directives', focus: 'Living Will vs Power of Attorney. RN role: Witness only.', videoQuery: 'nclex advanced directives nursing' },
        { name: 'Advocacy & Client Rights', focus: 'Refusal of treatment (AMA). Mental health rights.', videoQuery: 'patient advocacy nursing nclex' },
        { name: 'Confidentiality (HIPAA)', focus: 'No social media. No sharing with family w/o permission.', videoQuery: 'hipaa nursing scenarios nclex' },
        { name: 'Delegation (RN/LPN/UAP)', focus: 'The "EAT" rule (Evaluate, Assess, Teach = RN only).', videoQuery: 'delegation nursing nclex mark klimek' },
        { name: 'Ethical Practice', focus: 'Non-maleficence (do no harm), Beneficence, Veracity.', videoQuery: 'nursing ethics nclex principles' },
        { name: 'Informed Consent', focus: 'Provider explains risk. RN witnesses signature only.', videoQuery: 'informed consent nursing responsibility' },
        { name: 'Prioritization (Triage)', focus: 'Unstable > Stable. Acute > Chronic. Airway > Breathing.', videoQuery: 'nclex prioritization questions practice' }
      ],
      resources: [
        { title: 'NCSBN Test Plan', url: 'https://www.ncsbn.org/public-files/2023_RN_Test%20Plan_English_FINAL.pdf', type: 'Official' },
        { title: 'Mark Klimek - Leadership', url: 'https://www.youtube.com/results?search_query=mark+klimek+lecture+12+prioritization', type: 'Video' }
      ]
    },
    {
      category: 'Safe and Effective Care Environment',
      subcategory: 'Safety and Infection Control',
      percentage: '9-15%',
      icon: AlertCircle,
      color: 'text-orange-600',
      bg: 'bg-orange-50',
      borderColor: 'border-orange-100',
      desc: 'Protecting clients from health and environmental hazards.',
      expertTip: 'Memorize the Isolation Mnemonics. Airborne = MTV (Measles, TB, Varicella). Droplet = SPIDERMAN.',
      pitfall: 'Doning vs Doffing PPE order. Removal is alphabetical (Gloves, Goggles, Gown, Mask).',
      topics: [
        { name: 'Isolation Precautions', focus: 'Standard, Contact (C.Diff/MRSA), Droplet (Flu), Airborne (TB).', videoQuery: 'isolation precautions nursing mnemonics' },
        { name: 'Restraints', focus: 'Last resort. Check circulation q15-30min. New order q24h.', videoQuery: 'restraints nursing safety nclex' },
        { name: 'Fire Safety (RACE/PASS)', focus: 'Rescue, Alarm, Contain, Extinguish. Pull, Aim, Squeeze, Sweep.', videoQuery: 'fire safety nursing race pass' },
        { name: 'Emergency Response', focus: 'Triage codes (Red, Yellow, Green, Black). Disaster roles.', videoQuery: 'triage tags nursing disaster' },
        { name: 'Surgical Asepsis', focus: 'Sterile field rules. Never turn back on field. Waist high.', videoQuery: 'sterile field nursing skills' }
      ],
      resources: [
        { title: 'CDC Guidelines', url: 'https://www.cdc.gov/infectioncontrol/basics/transmission-based-precautions.html', type: 'Official' },
        { title: 'RegisteredNurseRN - PPE', url: 'https://www.youtube.com/watch?v=iwvnA_b9Q8Y', type: 'Video' }
      ]
    },
    {
      category: 'Health Promotion and Maintenance',
      subcategory: 'Growth & Dev / OB / Peds',
      percentage: '6-12%',
      icon: Baby,
      color: 'text-pink-600',
      bg: 'bg-pink-50',
      borderColor: 'border-pink-100',
      desc: 'From womb to tomb. OB, Pediatrics, and Aging.',
      expertTip: 'OB: Fetal Heart Rate (VEAL CHOP). Variable=Cord (Bad), Early=Head (Ok), Accel=Ok, Late=Placenta (Bad).',
      pitfall: 'Thinking every deceleration is bad. Early decels are normal during labor (head compression).',
      topics: [
        { name: 'Ante/Intra/Postpartum', focus: 'Stages of labor. Lochia assessment. Fundal height.', videoQuery: 'stages of labor nursing simple nursing' },
        { name: 'Newborn Assessment', focus: 'APGAR scoring. Reflexes (Moro, Babinski). Jaundice.', videoQuery: 'newborn assessment nursing nclex' },
        { name: 'Pediatric Milestones', focus: '2 mo (Smile), 6 mo (Sit), 12 mo (Walk). Fontanels close.', videoQuery: 'pediatric milestones nursing mnemonics' },
        { name: 'Immunization Schedule', focus: 'Hep B (Birth). MMR/Varicella (12 mo). No live vaccines for pregnant.', videoQuery: 'immunization schedule nursing mnemonic' },
        { name: 'Aging Process', focus: 'Normal vs Abnormal aging. Delirium vs Dementia.', videoQuery: 'geriatric nursing nclex review' }
      ],
      resources: [
        { title: 'SimpleNursing - OB Playlist', url: 'https://www.youtube.com/playlist?list=PL3NAm8U74E_s-MKyM19Fw5X86YJ3-LzP_', type: 'Video' }
      ]
    },
    {
      category: 'Psychosocial Integrity',
      subcategory: 'Mental Health',
      percentage: '6-12%',
      icon: Brain,
      color: 'text-purple-600',
      bg: 'bg-purple-50',
      borderColor: 'border-purple-100',
      desc: 'Mental health, addiction, and therapeutic communication.',
      expertTip: 'Therapeutic Comm: Never ask "Why". Never say "Don\'t worry". Acknowledge feelings. "It seems like you are upset..."',
      pitfall: 'Choosing answers that dismiss the patient\'s reality or offer false reassurance.',
      topics: [
        { name: 'Therapeutic Communication', focus: 'Open-ended questions. Silence. Active listening.', videoQuery: 'therapeutic communication nursing questions' },
        { name: 'Schizophrenia', focus: 'Positive (Hallucinations) vs Negative symptoms. Safety first.', videoQuery: 'schizophrenia nursing care plan' },
        { name: 'Bipolar Disorder', focus: 'Manic phase interventions (Finger foods, low stim environment).', videoQuery: 'bipolar disorder nursing interventions' },
        { name: 'Substance Abuse', focus: 'Alcohol withdrawal (Delirium Tremens). CIWA scale.', videoQuery: 'alcohol withdrawal nursing care' },
        { name: 'Personality Disorders', focus: 'Borderline (Splitting). Antisocial (Boundaries).', videoQuery: 'personality disorders nursing mnemonic' }
      ],
      resources: [
        { title: 'Level Up RN - Psych', url: 'https://www.youtube.com/playlist?list=PLj9YgcGZTVc6pE4OQ-3VvRzXyDwcNqgM-', type: 'Video' }
      ]
    },
    {
      category: 'Physiological Integrity',
      subcategory: 'Basic Care & Comfort',
      percentage: '6-9%',
      icon: Bone,
      color: 'text-teal-600',
      bg: 'bg-teal-50',
      borderColor: 'border-teal-100',
      desc: 'Mobility, Nutrition, Hygiene, and Elimination.',
      expertTip: 'Crutches are huge. "Up with the Good, Down with the Bad". Cane goes on the STRONG side.',
      pitfall: 'Placing the cane on the weak side. It must support the weak side by being on the strong side.',
      topics: [
        { name: 'Assistive Devices', focus: 'Crutches (stairs), Canes (strong side), Walkers.', videoQuery: 'crutch walking nursing mnemonic' },
        { name: 'Nutrition', focus: 'Renal Diet (Low K/Phos). Cardiac (Low Na). TPN rules.', videoQuery: 'nursing diets nutrition nclex' },
        { name: 'Tube Feeding (NGT)', focus: 'Check placement (pH). Residuals. HOB 30-45 degrees.', videoQuery: 'ng tube feeding nursing care' },
        { name: 'Mobility/Immobility', focus: 'DVT prevention. Pressure ulcer stages. Positioning.', videoQuery: 'pressure injuries nursing staging' },
        { name: 'Elimination', focus: 'Foley care (sterile). Ostomy care (stoma appearance).', videoQuery: 'ostomy care nursing procedure' }
      ],
      resources: [
        { title: 'RegisteredNurseRN - Skills', url: 'https://www.youtube.com/playlist?list=PLQrdx7rRsKfU9VlX5gZ5Y4X9Y8W9Y8W9Y', type: 'Video' }
      ]
    },
    {
      category: 'Physiological Integrity',
      subcategory: 'Pharmacological Therapies',
      percentage: '12-18%',
      icon: Syringe,
      color: 'text-red-600',
      bg: 'bg-red-50',
      borderColor: 'border-red-100',
      desc: 'Meds, IVs, and blood products. The hardest section for many.',
      expertTip: 'Know the "Narrow Therapeutic Index" drugs: Lithium (0.6-1.2), Digoxin (0.5-2), Phenytoin (10-20). Toxicity signs.',
      pitfall: 'Memorizing only brand names. NCLEX uses generics (Acetaminophen, not Tylenol).',
      topics: [
        { name: 'Cardiac Meds', focus: 'Beta Blockers (-lol/HR), ACEs (-pril/Cough), Digoxin (Toxicity).', videoQuery: 'cardiac meds nursing simple nursing' },
        { name: 'Psych Meds', focus: 'Lithium (Sodium levels), SSRIs (Serotonin Syndrome), MAOIs (Tyramine).', videoQuery: 'psych meds nursing pharmacology' },
        { name: 'Insulin Types', focus: 'Rapid (15m), Short (30m), Inter (Peak 4-12h), Long (No peak).', videoQuery: 'insulin peaks and onsets nursing' },
        { name: 'Anticoagulants', focus: 'Heparin (PTT/Protamine). Warfarin (INR/Vit K).', videoQuery: 'heparin vs warfarin nursing' },
        { name: 'IV Therapy', focus: 'Infiltration vs Phlebitis. TPN central line rules.', videoQuery: 'iv complications nursing infiltration phlebitis' }
      ],
      resources: [
        { title: 'SimpleNursing - Pharm Masterclass', url: 'https://www.youtube.com/playlist?list=PL3NAm8U74E_s-MKyM19Fw5X86YJ3-LzP_', type: 'Video' }
      ]
    },
    {
      category: 'Physiological Integrity',
      subcategory: 'Physiological Adaptation',
      percentage: '11-17%',
      icon: Activity,
      color: 'text-indigo-600',
      bg: 'bg-indigo-50',
      borderColor: 'border-indigo-100',
      desc: 'MedSurg topics: Fluids, Electrolytes, Emergencies, and Diseases.',
      expertTip: 'Potassium (K+) is Priority #1. High or Low = Cardiac Arrest. Sodium (Na+) = Neuro/Seizure.',
      pitfall: 'Confusing Hypo/Hyper symptoms. Remember: "Kalemias do same as prefix (except HR/Urine)".',
      topics: [
        { name: 'Fluid & Electrolytes', focus: 'Hyperkalemia (EKG changes). Hyponatremia (Seizure). Calcium (Tetany).', videoQuery: 'fluid and electrolytes nursing mnemonic' },
        { name: 'Acid-Base Balance', focus: 'ROME method. Respiratory Acidosis (COPD). Metabolic Acidosis (DKA).', videoQuery: 'abg interpretation nursing rome' },
        { name: 'Cardiac Rhythms', focus: 'V-Fib (Defib). Asystole (CPR). Sinus Tachy.', videoQuery: 'ekg rhythms nursing review' },
        { name: 'Endocrine', focus: 'Diabetes (DKA vs HHS). Thyroid (Graves vs Hashi). Addison vs Cushing.', videoQuery: 'endocrine system nursing review' },
        { name: 'Respiratory', focus: 'COPD (Low O2 drive). Asthma (Wheezing). Pneumonia.', videoQuery: 'respiratory nursing nclex review' }
      ],
      resources: [
        { title: 'RegisteredNurseRN - MedSurg', url: 'https://www.youtube.com/playlist?list=PLQrdx7rRsKfU9VlX5gZ5Y4X9Y8W9Y8W9Y', type: 'Video' }
      ]
    }
  ];

  const middleEastDeepDive = [
      {
        category: 'Fundamentals of Nursing',
        subcategory: 'Basic Nursing Care',
        percentage: '35-40%',
        icon: ShieldCheck,
        color: 'text-teal-600',
        bg: 'bg-teal-50',
        borderColor: 'border-teal-100',
        desc: 'Heavily weighted in DHA/Prometric. Focuses on standards of practice, hygiene, and mobility.',
        expertTip: 'Prometric loves numbers. Memorize normal vital signs, BMI ranges, and fluid calculation formulas (Drops/min) perfectly.',
        pitfall: 'Overthinking. Middle East exams are usually direct recall. If the question asks for normal BP, it is 120/80. No tricks.',
        topics: [
          { name: 'Vital Signs', focus: 'Normals for all ages. Temp conversion (F to C). Pulse sites.', videoQuery: 'vital signs nursing skill' },
          { name: 'Nursing Process', focus: 'ADPIE. Assessment is always first.', videoQuery: 'nursing process adpie' },
          { name: 'Positioning', focus: 'Fowlers (Breathing). Trendelenburg (Shock). Sim\'s (Enema).', videoQuery: 'patient positioning nursing' },
          { name: 'Wound Care', focus: 'Pressure ulcer staging (1-4). Dressing types.', videoQuery: 'pressure ulcer staging nursing' },
          { name: 'Catheterization', focus: 'Sterile technique. Size selection (French).', videoQuery: 'urinary catheterization nursing procedure' }
        ],
        resources: [
          { title: 'Fundamentals Review', url: 'https://www.youtube.com/watch?v=t5JvYmC0Zq8', type: 'Video' }
        ]
      },
      {
        category: 'Medical Surgical Nursing',
        subcategory: 'Adult Health',
        percentage: '30-35%',
        icon: Stethoscope,
        color: 'text-blue-600',
        bg: 'bg-blue-50',
        borderColor: 'border-blue-100',
        desc: 'Standard disease processes. Less critical thinking, more "What is the hallmark sign?"',
        expertTip: 'Focus on "Hallmark Signs". Example: Butterfly rash = Lupus. Moon face = Cushings. Barrel chest = COPD.',
        pitfall: 'Studying deep pathophysiology. They usually just ask for the main symptom or the main medication.',
        topics: [
          { name: 'Diabetes Mellitus', focus: 'Type 1 vs 2. Hypoglycemia signs. Foot care.', videoQuery: 'diabetes nursing care plan' },
          { name: 'Hypertension', focus: 'Stages. DASH diet. Med compliance.', videoQuery: 'hypertension nursing care' },
          { name: 'Respiratory Diseases', focus: 'COPD care. Asthma triggers. TB isolation.', videoQuery: 'copd nursing care' },
          { name: 'Post-Op Care', focus: 'Early ambulation. Deep breathing. Signs of infection.', videoQuery: 'post operative nursing care' },
          { name: 'Thyroid Disorders', focus: 'Hyper vs Hypo symptoms. Thyroid storm.', videoQuery: 'thyroid disorders nursing' }
        ],
        resources: [
          { title: 'Prometric MedSurg Review', url: 'https://www.youtube.com/results?search_query=dha+exam+questions+for+nurses', type: 'Video' }
        ]
      },
      {
        category: 'Maternal & Child Health',
        subcategory: 'OBG & Pediatrics',
        percentage: '15-20%',
        icon: HeartPulse,
        color: 'text-pink-600',
        bg: 'bg-pink-50',
        borderColor: 'border-pink-100',
        desc: 'Focus on EDD calculation, Immunization schedule, and normal milestones.',
        expertTip: 'Master Naegele’s Rule for EDD (LMP + 7 days - 3 months). It is a guaranteed question.',
        pitfall: 'Confusing EPI schedule (Bangladesh) with CDC schedule. Prometric usually follows international standards (WHO/CDC).',
        topics: [
          { name: 'EDD Calculation', focus: 'Naegele\'s Rule practice. Gravida/Para.', videoQuery: 'naegeles rule nursing' },
          { name: 'Stages of Labor', focus: '1st (Latent/Active/Trans), 2nd (Push), 3rd (Placenta).', videoQuery: 'stages of labor nursing' },
          { name: 'Immunization (EPI/WHO)', focus: 'BCG, Pentavalent, MR. Sites of injection.', videoQuery: 'epi schedule bangladesh nursing' },
          { name: 'Breastfeeding', focus: 'Latch techniques. Benefits. Storage of milk.', videoQuery: 'breastfeeding nursing education' },
          { name: 'Peds Infections', focus: 'Chickenpox, Measles, Mumps isolation.', videoQuery: 'pediatric communicable diseases nursing' }
        ],
        resources: [
          { title: 'Maternity Nursing Review', url: 'https://www.youtube.com/watch?v=F_f0tCjFpSg', type: 'Video' }
        ]
      }
  ];

  const currentData = activeTab === 'nclex' ? nclexDeepDive : middleEastDeepDive;

  return (
    <div className="space-y-6 pb-20 lg:pb-0 animate-fade-in">
      {/* Syllabus Header with Toggle */}
      <div className="bg-slate-900 p-6 rounded-2xl shadow-lg text-white">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-4">
            <div>
                <h1 className="text-2xl font-bold mb-2">Examination Syllabus</h1>
                <p className="text-slate-300 text-sm leading-relaxed">
                  Select your target exam. NCLEX tests <strong className="text-teal-400">Logic & Safety</strong>. Middle East tests <strong className="text-teal-400">Recall & Basics</strong>.
                </p>
            </div>
            
            {/* Toggle Switch */}
            <div className="bg-slate-800 p-1 rounded-lg inline-flex">
                <button 
                    onClick={() => setActiveTab('nclex')}
                    className={`flex items-center px-4 py-2 rounded-md text-sm font-bold transition-all ${activeTab === 'nclex' ? 'bg-teal-500 text-white shadow-sm' : 'text-slate-400 hover:text-white'}`}
                >
                    <Globe size={16} className="mr-2" /> NCLEX (USA)
                </button>
                <button 
                    onClick={() => setActiveTab('middleEast')}
                    className={`flex items-center px-4 py-2 rounded-md text-sm font-bold transition-all ${activeTab === 'middleEast' ? 'bg-teal-500 text-white shadow-sm' : 'text-slate-400 hover:text-white'}`}
                >
                    <Plane size={16} className="mr-2" /> DHA/Prometric
                </button>
            </div>
        </div>

        <div className="flex flex-wrap gap-2">
            {activeTab === 'nclex' ? (
                <>
                    <span className="px-2.5 py-1 rounded-md bg-white/10 text-white text-[10px] font-bold border border-white/20">NGN Format</span>
                    <span className="px-2.5 py-1 rounded-md bg-white/10 text-white text-[10px] font-bold border border-white/20">Clinical Judgment</span>
                    <span className="px-2.5 py-1 rounded-md bg-white/10 text-white text-[10px] font-bold border border-white/20">Adaptive (CAT)</span>
                </>
            ) : (
                <>
                    <span className="px-2.5 py-1 rounded-md bg-white/10 text-white text-[10px] font-bold border border-white/20">Linear Format</span>
                    <span className="px-2.5 py-1 rounded-md bg-white/10 text-white text-[10px] font-bold border border-white/20">Knowledge Based</span>
                    <span className="px-2.5 py-1 rounded-md bg-white/10 text-white text-[10px] font-bold border border-white/20">100-150 MCQs</span>
                </>
            )}
        </div>
      </div>

      <div className="space-y-4">
        {currentData.map((section, idx) => {
          const isExpanded = expandedSection === idx;
          return (
            <div key={idx} className={`bg-white rounded-xl border ${isExpanded ? 'border-teal-200 shadow-md' : 'border-slate-100 shadow-sm'} overflow-hidden transition-all duration-300`}>
              <button 
                onClick={() => setExpandedSection(isExpanded ? null : idx)}
                className={`w-full p-4 flex items-center justify-between ${section.bg} border-b ${isExpanded ? section.borderColor : 'border-transparent'}`}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg bg-white shadow-sm ${section.color}`}>
                    <section.icon size={20} />
                  </div>
                  <div className="text-left">
                    <h2 className="text-base font-bold text-slate-800 leading-tight">{section.subcategory}</h2>
                    <p className="text-[10px] font-semibold text-slate-500 uppercase tracking-wide mt-0.5">{section.category}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                    <span className="text-xs font-bold bg-white px-2 py-1 rounded text-slate-700 shadow-sm whitespace-nowrap hidden sm:block">
                        {section.percentage}
                    </span>
                    {isExpanded ? <ChevronUp size={20} className="text-slate-400" /> : <ChevronDown size={20} className="text-slate-400" />}
                </div>
              </button>

              {isExpanded && (
                <div className="p-4 sm:p-6 space-y-6 animate-fade-in">
                  
                  {/* Expert Strategy Section */}
                  <div className="bg-slate-50 rounded-xl p-4 border border-slate-100">
                     <h3 className="text-sm font-bold text-slate-800 mb-3 flex items-center">
                        <Target size={16} className="mr-2 text-teal-600" />
                        Strategy & Pitfalls
                     </h3>
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                         <div className="bg-white p-3 rounded-lg border border-teal-100 shadow-sm">
                            <span className="text-[10px] font-bold text-teal-600 uppercase mb-1 block flex items-center"><Lightbulb size={12} className="mr-1"/> Expert Tip</span>
                            <p className="text-sm text-slate-700">{section.expertTip}</p>
                         </div>
                         <div className="bg-white p-3 rounded-lg border border-red-100 shadow-sm">
                            <span className="text-[10px] font-bold text-red-600 uppercase mb-1 block flex items-center"><AlertCircle size={12} className="mr-1"/> Common Trap</span>
                            <p className="text-sm text-slate-700">{section.pitfall}</p>
                         </div>
                     </div>
                  </div>

                  {/* Topics Grid */}
                  <div>
                    <h3 className="text-sm font-bold text-slate-800 mb-3 flex items-center">
                        <BookOpen size={16} className="mr-2 text-blue-600" />
                        Detailed Topics & Study Links
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {section.topics.map((topic, tIdx) => (
                            <div key={tIdx} className="bg-white p-3 rounded-lg border border-slate-100 shadow-sm hover:shadow-md hover:border-teal-200 transition-all group">
                                <div className="flex justify-between items-start mb-2">
                                    <div className="flex items-center gap-2">
                                        <div className="h-1.5 w-1.5 rounded-full bg-teal-500 flex-shrink-0"></div>
                                        <span className="text-sm font-bold text-slate-800">{topic.name}</span>
                                    </div>
                                    <div className="flex gap-1">
                                        <button 
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                handleExplain(topic.name);
                                            }}
                                            className="p-1.5 text-slate-400 hover:text-teal-600 hover:bg-teal-50 rounded transition-colors"
                                            title="AI Explain"
                                        >
                                            <Sparkles size={14} />
                                        </button>
                                        <a 
                                            href={`https://www.youtube.com/results?search_query=${encodeURIComponent(topic.videoQuery)}`}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded transition-colors"
                                            title="Watch Video"
                                        >
                                            <PlayCircle size={14} />
                                        </a>
                                    </div>
                                </div>
                                <p className="text-xs text-slate-500 leading-relaxed pl-3.5 border-l-2 border-slate-100 group-hover:border-teal-100">
                                    <span className="font-semibold text-slate-600">Focus:</span> {topic.focus}
                                </p>
                            </div>
                        ))}
                    </div>
                  </div>

                  {/* General Resources */}
                  <div>
                    <h3 className="text-sm font-bold text-slate-800 mb-3 flex items-center">
                        <ExternalLink size={16} className="mr-2 text-purple-600" />
                        Key Resources
                    </h3>
                    <div className="flex flex-wrap gap-2">
                    {section.resources.map((resource, rIdx) => (
                        <a 
                        key={rIdx} 
                        href={resource.url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="flex items-center px-3 py-2 rounded-lg bg-slate-50 border border-slate-200 hover:bg-slate-100 hover:border-slate-300 transition-colors group/link"
                        >
                        <div className={`mr-2 flex-shrink-0 ${resource.type === 'Video' ? 'text-red-600' : 'text-blue-600'}`}>
                            {resource.type === 'Video' ? <Youtube size={14} /> : <ExternalLink size={14} />}
                        </div>
                        <div className="text-xs font-medium text-slate-700 group-hover/link:text-teal-700 transition-colors">{resource.title}</div>
                        </a>
                    ))}
                    </div>
                  </div>

                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* AI Explanation Modal */}
      {selectedTopic && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in" onClick={() => setSelectedTopic(null)}>
              <div 
                className="bg-white w-full max-w-lg rounded-t-2xl sm:rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh] sm:max-h-[80vh]" 
                onClick={e => e.stopPropagation()}
              >
                  <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-teal-50">
                      <div className="flex items-center gap-2 text-teal-800">
                          <Sparkles size={18} />
                          <h3 className="font-bold text-lg">AI Explanation</h3>
                      </div>
                      <button onClick={() => setSelectedTopic(null)} className="p-1 rounded-full hover:bg-teal-100 text-slate-500 hover:text-teal-700 transition-colors">
                          <X size={20} />
                      </button>
                  </div>
                  
                  <div className="p-6 overflow-y-auto">
                      <h4 className="text-xl font-bold text-slate-800 mb-4">{selectedTopic}</h4>
                      {loadingAi ? (
                          <div className="space-y-4 animate-pulse">
                              <div className="h-4 bg-slate-200 rounded w-3/4"></div>
                              <div className="h-4 bg-slate-200 rounded w-full"></div>
                              <div className="h-4 bg-slate-200 rounded w-5/6"></div>
                              <div className="h-32 bg-slate-100 rounded-lg"></div>
                          </div>
                      ) : (
                          <div className="prose prose-sm prose-teal max-w-none text-slate-700 leading-relaxed">
                             <div dangerouslySetInnerHTML={{ 
                                 __html: aiExplanation
                                    .replace(/\*\*(.*?)\*\*/g, '<strong class="text-slate-900">$1</strong>')
                                    .replace(/^# (.*$)/gim, '<h2 class="text-lg font-bold mt-4 mb-2">$1</h2>')
                                    .replace(/^## (.*$)/gim, '<h3 class="text-base font-bold mt-3 mb-1">$1</h3>')
                                    .replace(/\n/g, '<br />')
                                    .replace(/- /g, '• ') 
                             }} />
                          </div>
                      )}
                  </div>
                  <div className="p-4 border-t border-slate-100 bg-slate-50 text-center">
                     <p className="text-xs text-slate-400 italic">Powered by Gemini 3 Flash. Always verify with textbooks.</p>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};

export default Syllabus;