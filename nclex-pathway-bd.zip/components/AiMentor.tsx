import React, { useState, useEffect, useRef } from 'react';
import { generateNursingAdvice } from '../services/gemini';
import { ChatMessage, RoadmapStep } from '../types';
import { Send, Bot, User, Loader2, BrainCircuit, Eraser } from 'lucide-react';

interface AiMentorProps {
    roadmapData: RoadmapStep[];
}

const AiMentor: React.FC<AiMentorProps> = ({ roadmapData }) => {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  
  // Calculate user context
  const totalTasks = roadmapData.reduce((acc, step) => acc + step.tasks.length, 0);
  const completedTasks = roadmapData.reduce((acc, step) => acc + step.tasks.filter(t => t.completed).length, 0);
  const progress = Math.round((completedTasks / totalTasks) * 100);
  const currentStep = roadmapData.find(step => step.tasks.some(t => !t.completed))?.year || "Final Stage";

  const contextString = `User is a ${currentStep} student. Progress: ${progress}% completed.`;

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'model',
      text: `Hello! I'm your NCLEX Mentor. I see you're in **${currentStep}**. \n\nI can help you with:\n- Breaking down complex topics\n- Creating study schedules\n- Explaining CGFNS/Visa processes\n\nWhat's on your mind today?`,
      timestamp: new Date()
    }
  ]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const responseText = await generateNursingAdvice(userMsg.text, contextString);
      
      const botMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: responseText,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, botMsg]);
    } catch (error) {
       console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const formatMessage = (text: string) => {
    let formatted = text;
    
    // Bold: **text** -> <strong>text</strong>
    formatted = formatted.replace(/\*\*(.*?)\*\*/g, '<strong class="font-bold text-slate-900">$1</strong>');
    
    // Italic: *text* -> <em>text</em>
    formatted = formatted.replace(/\*(.*?)\*/g, '<em class="italic text-slate-700">$1</em>');

    // Headings: ## Heading -> <h3>Heading</h3>
    formatted = formatted.replace(/^##\s(.*$)/gm, '<h3 class="font-bold text-teal-700 mt-3 mb-1 text-sm uppercase tracking-wide">$1</h3>');
    
    // Bullet points: - item -> <li>item</li> (Simple replacement)
    // We wrap them in a span block for better spacing
    formatted = formatted.replace(/^- (.*$)/gm, '<div class="flex items-start my-1"><span class="mr-2 text-teal-500">•</span><span>$1</span></div>');
    
    // Numbered lists: 1. item -> <div>1. item</div>
    formatted = formatted.replace(/^\d+\. (.*$)/gm, '<div class="my-1 font-medium text-slate-700">$&</div>');

    // Line breaks
    formatted = formatted.replace(/\n/g, '<br/>');

    // Remove double breaks if they create too much space after headers
    formatted = formatted.replace(/<\/h3><br\/>/g, '</h3>');
    
    return formatted;
  };

  const suggestions = [
    "Explain 'Sepsis' priorities",
    "Study schedule for Pharmacology",
    "Difference between CGFNS & NNAS?",
    "Direct USA vs Middle East?"
  ];

  return (
    <div className="flex flex-col h-full bg-slate-50 lg:bg-white lg:rounded-2xl lg:border lg:border-slate-200 overflow-hidden lg:shadow-sm relative">
      
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-md border-b border-slate-100 p-4 flex items-center justify-between z-10 sticky top-0 flex-shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-teal-500 to-teal-700 flex items-center justify-center text-white shadow-md">
            <BrainCircuit size={20} />
          </div>
          <div>
            <h2 className="font-bold text-slate-800 text-base leading-tight">NCLEX Mentor</h2>
            <div className="flex items-center gap-1.5">
               <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
               <span className="text-xs text-slate-500 font-medium">Online</span>
            </div>
          </div>
        </div>
        <button 
            onClick={() => setMessages([messages[0]])}
            className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-full transition-colors"
            title="Clear Chat"
        >
            <Eraser size={18} />
        </button>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6 bg-slate-50 scroll-smooth">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-fade-in`}>
            
            {msg.role === 'model' && (
                <div className="flex-shrink-0 mr-3 hidden sm:block">
                    <div className="w-8 h-8 rounded-full bg-white border border-slate-200 flex items-center justify-center text-teal-600 shadow-sm">
                        <Bot size={16} />
                    </div>
                </div>
            )}

            <div 
                className={`max-w-[88%] sm:max-w-[75%] px-5 py-3.5 rounded-2xl text-[15px] leading-relaxed shadow-sm ${
                  msg.role === 'user' 
                    ? 'bg-slate-800 text-white rounded-tr-sm' 
                    : 'bg-white text-slate-700 border border-slate-100 rounded-tl-sm'
                }`}
            >
                <div 
                    dangerouslySetInnerHTML={{ __html: formatMessage(msg.text) }} 
                    className={msg.role === 'model' ? "prose-sm" : ""}
                />
                <div className={`text-[10px] mt-1.5 text-right opacity-70 ${msg.role === 'user' ? 'text-slate-300' : 'text-slate-400'}`}>
                    {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
            </div>

            {msg.role === 'user' && (
                <div className="flex-shrink-0 ml-3 hidden sm:block">
                     <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-slate-500">
                        <User size={16} />
                    </div>
                </div>
            )}
          </div>
        ))}
        
        {loading && (
           <div className="flex justify-start animate-pulse">
             <div className="flex-shrink-0 mr-3 hidden sm:block">
                <div className="w-8 h-8 rounded-full bg-white border border-slate-200 flex items-center justify-center text-teal-600 shadow-sm">
                    <Bot size={16} />
                </div>
             </div>
             <div className="bg-white px-5 py-3 rounded-2xl rounded-tl-sm border border-slate-100 shadow-sm flex items-center gap-2">
                 <Loader2 size={16} className="animate-spin text-teal-500" />
                 <span className="text-sm text-slate-400 font-medium">Thinking...</span>
             </div>
           </div>
        )}
        <div ref={messagesEndRef} className="h-4" />
      </div>

      {/* Input Area */}
      <div className="bg-white border-t border-slate-100 p-3 sm:p-4 pb-safe z-20 flex-shrink-0">
        
        {/* Quick Suggestions */}
        {!loading && messages.length < 5 && (
            <div className="flex gap-2 overflow-x-auto pb-3 mb-1 scrollbar-hide snap-x px-1">
                {suggestions.map((s, i) => (
                    <button 
                        key={i}
                        onClick={() => setInput(s)}
                        className="flex-shrink-0 snap-start px-4 py-2 bg-slate-50 hover:bg-teal-50 hover:text-teal-700 hover:border-teal-200 border border-slate-200 rounded-full text-xs font-semibold text-slate-600 transition-all active:scale-95 shadow-sm"
                    >
                        {s}
                    </button>
                ))}
            </div>
        )}

        <div className="relative flex items-end gap-2">
            <div className="flex-1 bg-slate-100 rounded-3xl border border-transparent focus-within:border-slate-300 focus-within:bg-white transition-all shadow-inner">
                <textarea
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault();
                            handleSend();
                        }
                    }}
                    placeholder="Ask your mentor..."
                    className="w-full bg-transparent border-none focus:ring-0 text-[15px] text-slate-800 placeholder-slate-400 min-h-[48px] max-h-[120px] py-3 px-4 resize-none rounded-3xl"
                    rows={1}
                    disabled={loading}
                    style={{ height: '48px' }}
                />
            </div>
            
            <button
                onClick={handleSend}
                disabled={loading || !input.trim()}
                className={`w-12 h-12 flex items-center justify-center rounded-full shadow-md transition-all duration-200 ${
                    !input.trim() 
                    ? 'bg-slate-200 text-slate-400 cursor-not-allowed' 
                    : 'bg-slate-900 text-white hover:bg-teal-600 hover:scale-105 active:scale-95'
                }`}
            >
                {loading ? <Loader2 size={20} className="animate-spin" /> : <Send size={20} className="ml-0.5" />}
            </button>
        </div>
        
        <p className="text-[10px] text-center text-slate-400 mt-3 font-medium">
            AI can make mistakes. Always verify medical info.
        </p>
      </div>
    </div>
  );
};

export default AiMentor;