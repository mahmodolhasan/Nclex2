import React from 'react';
import { ShieldCheck, FileText, Globe, CheckCircle2, Clock, DollarSign, ExternalLink, Youtube, HelpCircle } from 'lucide-react';

const NclexGuide: React.FC = () => {
  const steps = [
    {
      title: 'Step 1: CGFNS Credentials Evaluation',
      time: '6-8 Months',
      cost: '$450 approx (~52,000 BDT)',
      icon: FileText,
      desc: 'The "Gatekeeper" step. CGFNS verifies if your BD Nursing Degree is authentic and comparable to US education.',
      details: [
        'Create account at CGFNS International (cgfns.org)',
        'Order "CES Professional Report" (required by NY, TX, etc.)',
        'Download forms for your Nursing College and Bangladesh Nursing Midwifery Council (BNMC).',
        'Physical verification is often required at BNMC in Dhaka.',
        'BNMC must send the documents directly to CGFNS (Via DHL/FedEx).'
      ],
      links: [
        { label: 'CGFNS Official Site', url: 'https://www.cgfns.org/' },
        { label: 'CGFNS CES Report Info', url: 'https://www.cgfns.org/services/certification/ces-professional/' }
      ],
      videoSearch: 'how to apply cgfns from bangladesh'
    },
    {
      title: 'Step 2: English Proficiency',
      time: '1-3 Months',
      cost: '$200 - $300 (~25,000 BDT)',
      icon: Globe,
      desc: 'Most State Boards require an English score. Some states waive it if your instruction was in English, but Visa Screen ALWAYS requires it.',
      details: [
        'IELTS Academic: 6.5 Overall (Must have 7.0 in Speaking for VisaScreen).',
        'PTE Academic: Accepted by some boards (like Texas). Easier to score high.',
        'TOEFL iBT: The traditional standard (83+ Total, 26+ Speaking).'
      ],
      links: [
        { label: 'IELTS Registration BD', url: 'https://www.britishcouncil.org.bd/en/exam/ielts' },
        { label: 'PTE Official', url: 'https://www.pearsonpte.com/' }
      ],
      videoSearch: 'ielts vs pte for nurses'
    },
    {
      title: 'Step 3: Apply to Board of Nursing (BON)',
      time: '3-5 Months',
      cost: '$100 - $200 (~15,000 BDT)',
      icon: ShieldCheck,
      desc: 'You must apply to a specific US state. You can endorse (transfer) this license later, but pick a "student friendly" state first.',
      details: [
        'New York (NY): Does not require SSN to apply. Very slow processing.',
        'Texas (TX): Fast, requires CGFNS CES. Needs SSN (or waiver form).',
        'Submit application online at the specific BON website.',
        'Complete Criminal Background Check (IdentoGO fingerprinting card).'
      ],
      links: [
        { label: 'New York State Education Dept (Nursing)', url: 'https://www.op.nysed.gov/professions/registered-professional-nursing' },
        { label: 'Texas Board of Nursing', url: 'https://www.bon.texas.gov/' }
      ],
      videoSearch: 'new york vs texas nursing board for international students'
    },
    {
      title: 'Step 4: Register with Pearson Vue',
      time: 'Immediate',
      cost: '$200 (~23,000 BDT)',
      icon: CheckCircle2,
      desc: 'Once the Board approves you, they send an "Eligibility" email. Now you pay for the exam.',
      details: [
        'Create account on Pearson Vue NCLEX website.',
        'Pay the $200 exam fee.',
        'Wait for ATT (Authorization to Test) code via email. Valid for 90 days usually.'
      ],
      links: [
        { label: 'Pearson Vue NCLEX', url: 'https://home.pearsonvue.com/nclex' }
      ],
      videoSearch: 'how to register pearson vue nclex'
    },
    {
      title: 'Step 5: Schedule & Take Exam',
      time: 'Exam day',
      cost: '$150 Intl Fee (~17,000 BDT) + Travel',
      icon: Clock,
      desc: 'There is no NCLEX center in Bangladesh yet. You must travel.',
      details: [
        'India (Delhi/Bangalore/Chennai): Closest option. Requires Visa.',
        'Philippines (Manila): Popular, cheap flights.',
        'Exam: 5 hours max. 85-150 Questions. Adaptive difficulty.',
        'Results: Quick Results available in 48 hours ($8 fee).'
      ],
      links: [
        { label: 'NCLEX Candidate Bulletin', url: 'https://www.ncsbn.org/exams/testplans.page' }
      ],
      videoSearch: 'nclex exam day experience india'
    }
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-blue-50 border-l-4 border-blue-600 p-6 rounded-r-xl">
        <h2 className="text-xl font-bold text-blue-900 mb-2">NCLEX-RN Application Guide</h2>
        <p className="text-blue-800 text-sm leading-relaxed">
          The journey from BD to USA is long (12-18 months minimum). <strong>Start CGFNS (Step 1) while you are in your internship</strong> or immediately after graduation. Documents verification is the biggest bottleneck.
        </p>
      </div>

      <div className="relative">
        <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-slate-200 hidden md:block"></div>
        <div className="space-y-8">
          {steps.map((step, idx) => (
            <div key={idx} className="relative flex flex-col md:flex-row gap-6 bg-white p-6 rounded-xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
              <div className="md:w-12 md:h-12 w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center flex-shrink-0 z-10 border-4 border-white shadow-sm">
                <step.icon size={20} />
              </div>
              <div className="flex-1">
                <div className="flex flex-col md:flex-row md:items-center justify-between mb-2">
                  <h3 className="text-lg font-bold text-slate-800">{step.title}</h3>
                  <div className="flex flex-wrap gap-2 mt-1 md:mt-0">
                    <span className="text-xs font-semibold bg-slate-100 px-2 py-1 rounded text-slate-600 flex items-center">
                      <Clock size={12} className="mr-1" /> {step.time}
                    </span>
                    <span className="text-xs font-semibold bg-green-50 px-2 py-1 rounded text-green-700 flex items-center border border-green-100">
                      <DollarSign size={12} className="mr-1" /> {step.cost}
                    </span>
                  </div>
                </div>
                <p className="text-sm text-slate-600 mb-4">{step.desc}</p>
                <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                  <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Action Items</h4>
                  <ul className="space-y-2 mb-4">
                    {step.details.map((detail, dIdx) => (
                      <li key={dIdx} className="text-sm text-slate-700 flex items-start">
                        <span className="mr-2 text-blue-500">•</span>
                        {detail}
                      </li>
                    ))}
                  </ul>
                  
                  {/* Links Section */}
                  <div className="flex flex-wrap gap-2 mt-4 pt-3 border-t border-slate-200">
                     {step.links?.map((link, lIdx) => (
                         <a 
                           key={lIdx} 
                           href={link.url} 
                           target="_blank" 
                           rel="noopener noreferrer"
                           className="flex items-center px-3 py-1.5 bg-white border border-slate-300 rounded text-xs font-medium text-slate-700 hover:text-blue-600 hover:border-blue-300 transition-colors"
                         >
                             <ExternalLink size={12} className="mr-1.5" /> {link.label}
                         </a>
                     ))}
                     {step.videoSearch && (
                         <a 
                           href={`https://www.youtube.com/results?search_query=${encodeURIComponent(step.videoSearch)}`}
                           target="_blank" 
                           rel="noopener noreferrer"
                           className="flex items-center px-3 py-1.5 bg-red-50 border border-red-100 rounded text-xs font-medium text-red-600 hover:bg-red-100 transition-colors"
                         >
                             <Youtube size={12} className="mr-1.5" /> Watch Tutorial
                         </a>
                     )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      <div className="bg-white p-6 rounded-xl border border-slate-100 shadow-sm mt-8">
          <h3 className="font-bold text-slate-800 flex items-center mb-4">
              <HelpCircle size={20} className="mr-2 text-teal-600" />
              Common Questions
          </h3>
          <div className="space-y-4">
              <div className="p-3 bg-slate-50 rounded-lg">
                  <h4 className="font-bold text-sm text-slate-800 mb-1">Do I need clinical experience for NCLEX?</h4>
                  <p className="text-sm text-slate-600">No. Unlike the Middle East, most US Boards (NY, TX) do not require experience to sit for the exam. You can take it fresh out of college.</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg">
                  <h4 className="font-bold text-sm text-slate-800 mb-1">Can I take the exam in Bangladesh?</h4>
                  <p className="text-sm text-slate-600">No. Currently, you must travel to India (Delhi) or the Philippines. Factor in Visa processing times for India.</p>
              </div>
          </div>
      </div>
    </div>
  );
};

export default NclexGuide;