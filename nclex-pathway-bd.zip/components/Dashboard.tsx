import React, { useEffect, useState } from 'react';
import { RoadmapStep } from '../types';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { GraduationCap, Plane, BookOpen, Activity, Bell, ArrowRight, RefreshCw, Sparkles } from 'lucide-react';
import { generateDailyInsight } from '../services/gemini';

interface DashboardProps {
  roadmapData: RoadmapStep[];
}

interface DailyInsight {
  topic: string;
  content: string;
  actions: string[];
  date: string;
}

const Dashboard: React.FC<DashboardProps> = ({ roadmapData }) => {
  // Calculate progress
  const totalTasks = roadmapData.reduce((acc, step) => acc + step.tasks.length, 0);
  const completedTasks = roadmapData.reduce((acc, step) => acc + step.tasks.filter(t => t.completed).length, 0);
  const progressPercentage = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  // Get Upcoming Reminders
  const reminders = roadmapData
    .flatMap(step => step.tasks.map(task => ({ ...task, stepTitle: step.title })))
    .filter(task => task.reminder && !task.completed)
    .sort((a, b) => new Date(a.reminder!).getTime() - new Date(b.reminder!).getTime())
    .slice(0, 3); // Top 3

  const data = [
    { name: 'Completed', value: completedTasks },
    { name: 'Remaining', value: totalTasks - completedTasks },
  ];

  const COLORS = ['#0d9488', '#e2e8f0'];

  // Daily Insight State - Initialized with specific Fundamentals content
  const [dailyInsight, setDailyInsight] = useState<DailyInsight>({
    topic: "Focus on Fundamentals",
    content: "For a 2nd-year student, your priority isn't solving complex UWorld questions yet. It's understanding Pathophysiology and Pharmacology deep down. The NCLEX asks \"Why?\" and \"What next?\". If you understand the 'Why' (Patho), the 'What next' (Interventions) becomes easy.",
    actions: [
      "Review fluid and electrolytes balance (Hypo/Hyperkalemia).",
      "Watch 1 SimpleNursing video on Cardiac Meds.",
      "Read 5 pages of Saunders Comprehensive Review (Unit 1)."
    ],
    date: new Date().toDateString()
  });
  const [loadingInsight, setLoadingInsight] = useState(false);

  useEffect(() => {
    const checkInsight = async () => {
      const today = new Date().toDateString();
      const savedInsight = localStorage.getItem('daily_insight');
      
      if (savedInsight) {
        const parsed: DailyInsight = JSON.parse(savedInsight);
        if (parsed.date === today) {
          setDailyInsight(parsed);
          return;
        }
      }

      // If no insight for today, fetch new (only if API key is set, otherwise fallback logic in service handles it)
      await fetchNewInsight();
    };

    checkInsight();
  }, []);

  const fetchNewInsight = async () => {
    setLoadingInsight(true);
    try {
      const insight = await generateDailyInsight();
      const newInsight = { ...insight, date: new Date().toDateString() };
      setDailyInsight(newInsight);
      localStorage.setItem('daily_insight', JSON.stringify(newInsight));
    } catch (e) {
      console.error(e);
      // Keep existing state on error
    } finally {
      setLoadingInsight(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in pb-4 lg:pb-0">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
        <div className="bg-white p-4 md:p-6 rounded-xl shadow-sm border border-slate-100 flex flex-col md:flex-row items-center md:space-x-4 space-y-2 md:space-y-0 text-center md:text-left">
          <div className="p-2 md:p-3 bg-teal-100 text-teal-600 rounded-full">
            <Activity size={20} className="md:w-6 md:h-6" />
          </div>
          <div>
            <p className="text-xs md:text-sm text-slate-500 font-medium">Current</p>
            <h3 className="text-sm md:text-xl font-bold text-slate-800">2nd Year</h3>
          </div>
        </div>

        <div className="bg-white p-4 md:p-6 rounded-xl shadow-sm border border-slate-100 flex flex-col md:flex-row items-center md:space-x-4 space-y-2 md:space-y-0 text-center md:text-left">
          <div className="p-2 md:p-3 bg-blue-100 text-blue-600 rounded-full">
            <GraduationCap size={20} className="md:w-6 md:h-6" />
          </div>
          <div>
            <p className="text-xs md:text-sm text-slate-500 font-medium">Ready</p>
            <h3 className="text-sm md:text-xl font-bold text-slate-800">{progressPercentage}%</h3>
          </div>
        </div>

        <div className="bg-white p-4 md:p-6 rounded-xl shadow-sm border border-slate-100 flex flex-col md:flex-row items-center md:space-x-4 space-y-2 md:space-y-0 text-center md:text-left">
          <div className="p-2 md:p-3 bg-indigo-100 text-indigo-600 rounded-full">
            <BookOpen size={20} className="md:w-6 md:h-6" />
          </div>
          <div>
            <p className="text-xs md:text-sm text-slate-500 font-medium">Topics</p>
            <h3 className="text-sm md:text-xl font-bold text-slate-800">12 Core</h3>
          </div>
        </div>

        <div className="bg-white p-4 md:p-6 rounded-xl shadow-sm border border-slate-100 flex flex-col md:flex-row items-center md:space-x-4 space-y-2 md:space-y-0 text-center md:text-left">
          <div className="p-2 md:p-3 bg-orange-100 text-orange-600 rounded-full">
            <Plane size={20} className="md:w-6 md:h-6" />
          </div>
          <div>
            <p className="text-xs md:text-sm text-slate-500 font-medium">Goal</p>
            <h3 className="text-sm md:text-xl font-bold text-slate-800">USA</h3>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Progress Chart */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 lg:col-span-1">
          <h3 className="text-base md:text-lg font-bold text-slate-800 mb-4">Preparation Roadmap</h3>
          <div className="h-48 md:h-64 relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={70}
                  fill="#8884d8"
                  paddingAngle={5}
                  dataKey="value"
                  stroke="none"
                >
                  {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex items-center justify-center flex-col pointer-events-none">
                <span className="text-2xl md:text-3xl font-bold text-slate-800">{progressPercentage}%</span>
                <span className="text-[10px] md:text-xs text-slate-500">Completed</span>
            </div>
          </div>
          
          {/* Upcoming Reminders Widget */}
          <div className="mt-6 border-t border-slate-100 pt-4">
             <h4 className="text-sm font-bold text-slate-700 mb-3 flex items-center">
                 <Bell size={16} className="mr-2 text-teal-500" />
                 Upcoming Reminders
             </h4>
             {reminders.length > 0 ? (
                 <div className="space-y-2">
                     {reminders.map(task => (
                         <div key={task.id} className="flex flex-col bg-slate-50 p-2 rounded text-xs border border-slate-100">
                             <div className="flex justify-between items-center mb-1">
                                 <span className="font-semibold text-slate-800 truncate max-w-[70%]">{task.text}</span>
                                 <span className={`px-1.5 py-0.5 rounded-full text-[10px] ${new Date(task.reminder!) < new Date() ? 'bg-red-100 text-red-600' : 'bg-teal-100 text-teal-600'}`}>
                                     {new Date(task.reminder!).toLocaleDateString(undefined, {month:'short', day:'numeric'})}
                                 </span>
                             </div>
                             <span className="text-slate-500">{new Date(task.reminder!).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})}</span>
                         </div>
                     ))}
                 </div>
             ) : (
                 <p className="text-xs text-slate-400 italic">No active reminders set.</p>
             )}
          </div>
        </div>

        {/* Daily Motivation & Tips */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 lg:col-span-2 flex flex-col relative overflow-hidden">
          <div className="flex justify-between items-start mb-4">
             <h3 className="text-base md:text-lg font-bold text-slate-800 flex items-center">
               <Sparkles size={18} className="mr-2 text-amber-500" />
               Daily NCLEX Insight
             </h3>
             <button 
                onClick={fetchNewInsight} 
                disabled={loadingInsight}
                className={`p-2 rounded-full hover:bg-slate-100 text-slate-400 hover:text-teal-600 transition-all ${loadingInsight ? 'animate-spin' : ''}`}
                title="Refresh Insight"
             >
                <RefreshCw size={16} />
             </button>
          </div>

          <div className="bg-teal-50 border-l-4 border-teal-500 p-4 mb-4 rounded-r-lg transition-all">
            <h4 className="font-semibold text-teal-800 text-sm md:text-base mb-1">{dailyInsight.topic}</h4>
            <p className="text-teal-700 text-sm md:text-base leading-relaxed">
              {dailyInsight.content}
            </p>
          </div>

          <div className="flex-1">
             <h4 className="font-semibold text-slate-700 mb-3 text-sm md:text-base">Quick Actions for Today:</h4>
             <ul className="space-y-2">
                {dailyInsight.actions.map((action, idx) => (
                    <li key={idx} className="flex items-start text-sm md:text-base text-slate-600">
                        <span className="mr-2 text-teal-500 mt-1">•</span>
                        {action}
                    </li>
                ))}
             </ul>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100">
             <a href="#" className="flex items-center text-sm font-bold text-teal-600 hover:text-teal-700 transition-colors">
                 Go to Study Syllabus <ArrowRight size={16} className="ml-1" />
             </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;