
export type View = 'dashboard' | 'roadmap' | 'resources' | 'pathways' | 'mentor' | 'syllabus';

export interface StudyResource {
  id: string;
  title: string;
  type: 'Book' | 'YouTube' | 'Website' | 'QBank';
  author?: string;
  description: string;
  link?: string;
  recommendedFor: string;
  tags: string[];
  // New Expert Fields
  price?: string; // e.g., "Free" or "2500 BDT"
  bestPhase: 'Phase 1: Content' | 'Phase 2: Strategy' | 'Phase 3: Practice' | 'Phase 4: Review';
  studyStrategy: string; // The "How to use" guide
  warning?: string; // Common mistakes
}

export interface CareerPath {
  id: string;
  country: string;
  pros: string[];
  cons: string[];
  risks: string[];
  timeline: string;
  cost: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export interface RoadmapTask {
  id: string;
  text: string;
  completed: boolean;
  reminder?: string; // ISO Date String
}

export interface RoadmapStep {
  id: string;
  year: string;
  title: string;
  mentorTip?: string; // Expert advice for this stage
  warnings?: string[]; // Things to watch out for
  tasks: RoadmapTask[];
}
