import { GoogleGenAI, SchemaType, Type } from "@google/genai";

const apiKey = process.env.API_KEY || '';

const ai = new GoogleGenAI({ apiKey });

export const generateNursingAdvice = async (prompt: string, context?: string): Promise<string> => {
  if (!apiKey) {
    return "API Key is missing. Please configure the environment variable to access the AI Mentor.";
  }

  try {
    const model = 'gemini-3-flash-preview';
    const systemInstruction = `You are a strict and professional NCLEX Mentor for a Bangladeshi nursing student.
        
        ${context ? `CONTEXT: ${context}` : ''}

        Rules:
        1. Keep answers SHORT and SCANNABLE. Mobile users hate walls of text.
        2. Use bullet points (- item) for lists.
        3. Do NOT use markdown bolding (like **text**) or italics. Use plain text only.
        4. Do NOT use headers (###).
        5. Tone: Encouraging but firm. "Tough love".
        
        Knowledge Base:
        - Bangladesh Nursing Council (BNMC) rules.
        - CGFNS / VisaScreen / EB-3 Visa.
        - NCLEX-RN (NGN) logic.
        - Middle East (DHA/HAAD) as a backup plan.
        `;

    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
      }
    });

    return response.text || "Sorry, I couldn't generate a response at this time.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "An error occurred while fetching advice. Please try again later.";
  }
};

export const explainNclexTopic = async (topic: string): Promise<string> => {
    if (!apiKey) {
        return "API Key is missing.";
    }

    try {
        const model = 'gemini-3-flash-preview';
        const prompt = `Explain "${topic}" for NCLEX-RN.
        Structure:
        1. Definition: 1 sentence.
        2. Patho: Simple breakdown.
        3. Interventions: Priority list.
        4. NCLEX Tip: Common trap.
        
        Keep it clean. No complex markdown. No **bold** or ## headers.`;

        const response = await ai.models.generateContent({
            model: model,
            contents: prompt,
            config: {
                temperature: 0.7 
            }
        });
        return response.text || "No explanation available.";
    } catch (e) {
        console.error(e);
        return "Failed to explain topic.";
    }
}

export const generateDailyInsight = async (): Promise<{topic: string, content: string, actions: string[]}> => {
  if (!apiKey) {
    return {
      topic: "Focus on Fundamentals",
      content: "For a 2nd-year student, your priority isn't solving complex UWorld questions yet. It's understanding Pathophysiology and Pharmacology deep down. The NCLEX asks \"Why?\" and \"What next?\". If you understand the 'Why' (Patho), the 'What next' (Interventions) becomes easy.",
      actions: [
        "Review fluid and electrolytes balance (Hypo/Hyperkalemia).",
        "Watch 1 SimpleNursing video on Cardiac Meds.",
        "Read 5 pages of Saunders Comprehensive Review (Unit 1)."
      ]
    };
  }

  try {
    const model = 'gemini-3-flash-preview';
    const response = await ai.models.generateContent({
      model: model,
      contents: "Generate a short, punchy daily insight for a nursing student. JSON format.",
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            topic: { type: Type.STRING },
            content: { type: Type.STRING },
            actions: { 
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          }
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response text");
    return JSON.parse(text);
  } catch (error) {
    console.error("Failed to generate daily insight", error);
    return {
      topic: "Focus on Fundamentals",
      content: "For a 2nd-year student, your priority isn't solving complex UWorld questions yet. It's understanding Pathophysiology and Pharmacology deep down. The NCLEX asks \"Why?\" and \"What next?\". If you understand the 'Why' (Patho), the 'What next' (Interventions) becomes easy.",
      actions: [
        "Review fluid and electrolytes balance (Hypo/Hyperkalemia).",
        "Watch 1 SimpleNursing video on Cardiac Meds.",
        "Read 5 pages of Saunders Comprehensive Review (Unit 1)."
      ]
    };
  }
};