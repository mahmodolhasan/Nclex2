import React, { useState, useEffect } from 'react';
import { LayoutDashboard, Map, BookOpen, Compass, MessageSquare, FileText, User } from 'lucide-react';
import Dashboard from './components/Dashboard';
import Roadmap from './components/Roadmap';
import Resources from './components/Resources';
import CareerPathways from './components/CareerPathways';
import AiMentor from './components/AiMentor';
import Syllabus from './components/Syllabus';
import MobileNav from './components/MobileNav';
import { View, RoadmapStep } from './types';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>('dashboard');

  // Initial Data - Highly Research-Based for BD Context
  const defaultRoadmapData: RoadmapStep[] = [
    {
      id: 'y2',
      year: 'Year 2: Foundation & Terms',
      title: 'Building the Base',
      mentorTip: "This is the 'Golden Period'. If you fail to grasp Anatomy & Physiology now, MedSurg in Year 3 will be a nightmare. Don't just pass college exams; understand the body systems.",
      warnings: ["Do not rely solely on college 'suggestions' or hand notes.", "Start getting comfortable with Medical English now."],
      tasks: [
        { id: '1', text: 'Master Medical Terminology: Crucial for non-native English speakers. Learn prefixes/suffixes.', completed: true },
        { id: '2', text: 'Pharmacology Phase 1: Memorize Drug Classes & Suffixes (e.g., -lol for Beta Blockers) not just brand names.', completed: false },
        { id: '3', text: 'Buy "Saunders Comprehensive Review" (South Asian Edition is fine, but US edition is better for values).', completed: false },
        { id: '4', text: 'Youtube Strategy: Watch 1 SimpleNursing video daily on topics covered in college lectures.', completed: false },
      ]
    },
    {
      id: 'y3',
      year: 'Year 3: Clinical & Critical Thinking',
      title: 'Connecting Theory to Practice',
      mentorTip: "In BD Govt hospitals, students are often treated as 'vital sign machines'. Break this cycle. Pick one patient, read their file, and ask 'Why is this specific med ordered?'.",
      warnings: ["Don't waste clinical hours just chatting at the nurses' station.", "Avoid 'procedure-only' focus; focus on the 'Why'."],
      tasks: [
        { id: '1', text: 'Hospital Rotation Strategy: In Ward/ICU, look at patient files. Correlate Labs (Na+, K+) with symptoms.', completed: false },
        { id: '2', text: 'Start Mark Klimek Audio (Lectures 1-12). Listen while commuting to college.', completed: false },
        { id: '3', text: 'English Prep: Start watching Netflix/Movies without subtitles to improve listening skills for IELTS.', completed: false },
        { id: '4', text: 'Financial Planning: Open a DPS/Savings account. You need ~1.5 Lac BDT ready for Year 4 applications.', completed: false },
      ]
    },
    {
      id: 'y4',
      year: 'Year 4: The Application Phase',
      title: 'Pre-Licensure Strategy',
      mentorTip: "The #1 delay for BD nurses is 'Name Mismatch'. Check your SSC, HSC, NID, and Passport. Every letter must match EXACTLY. Fix it now, not after graduation.",
      warnings: ["Passport validity must be >2 years.", "Ensure your Nursing College sends the Transcript strictly in the CGFNS format."],
      tasks: [
        { id: '1', text: 'Passport: Ensure you have a valid Passport with >2 years validity.', completed: false },
        { id: '2', text: 'IELTS/PTE: Take this BEFORE internship. Target: IELTS 7.0 (R:7, L:7, S:7, W:6.5) for VisaScreen.', completed: false },
        { id: '3', text: 'Start CGFNS Account: You can create the profile before graduation. Familiarize with the forms.', completed: false },
        { id: '4', text: 'Review: Focus on Mental Health & OBG Nursing (High yield in NCLEX).', completed: false },
      ]
    },
    {
      id: 'intern',
      year: 'Internship',
      title: 'Documentation Hell',
      mentorTip: "Apply for BNMC Registration the moment you are eligible. It takes months. Physically visit BNMC in Dhaka to track your file if it gets stuck.",
      warnings: ["Do not give your original certificates to agents.", "CGFNS validation expires, so time your application correctly."],
      tasks: [
        { id: '1', text: 'BNMC Registration: Apply for Registration immediately. Do not delay.', completed: false },
        { id: '2', text: 'CGFNS Application: Submit CES Report application once you get your Transcript/Provisional Cert.', completed: false },
        { id: '3', text: 'Verification Run: Physically visit BNMC to ensure they send documents to CGFNS/Dataflow.', completed: false },
        { id: '4', text: 'Job Hunt: Try to get into a JCI Accredited hospital (Apollo/Square/United) for better US resume value.', completed: false },
      ]
    },
    {
      id: 'post-grad',
      year: 'Post-Grad / Gap',
      title: 'The "Waiting" Game',
      mentorTip: "Employment gap is a red flag. Never sit idle. Even a clinic job is better than no job. If US process stalls, start DHA (Dubai) process as a backup to keep skills sharp.",
      warnings: ["Avoid 'Gap Years'.", "Don't let your English skills rust while waiting."],
      tasks: [
        { id: '1', text: 'Gap Management: Do NOT stay unemployed >6 months. Clinical gap hurts Middle East applications.', completed: false },
        { id: '2', text: 'Middle East Backup: If US delay >1 year, start Dataflow for DHA (Dubai) to gain international experience.', completed: false },
        { id: '3', text: 'NCLEX Date: Once you get ATT, schedule exam in India (Delhi). Plan Visa 2 months ahead.', completed: false },
      ]
    }
  ];

  // Load from Local Storage or use Default
  const [roadmapData, setRoadmapData] = useState<RoadmapStep[]>(() => {
    try {
      const saved = localStorage.getItem('nursepath_roadmap');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.error("Failed to load from local storage", e);
    }
    return defaultRoadmapData;
  });

  // Save to Local Storage whenever roadmapData changes
  useEffect(() => {
    try {
      localStorage.setItem('nursepath_roadmap', JSON.stringify(roadmapData));
    } catch (e) {
      console.error("Failed to save to local storage", e);
    }
  }, [roadmapData]);

  const toggleTask = (stepId: string, taskId: string) => {
    setRoadmapData(prev => prev.map(step => {
      if (step.id !== stepId) return step;
      return {
        ...step,
        tasks: step.tasks.map(task => 
          task.id === taskId ? { ...task, completed: !task.completed } : task
        )
      };
    }));
  };

  const setReminder = (stepId: string, taskId: string, date: string | undefined) => {
    setRoadmapData(prev => prev.map(step => {
      if (step.id !== stepId) return step;
      return {
        ...step,
        tasks: step.tasks.map(task => 
          task.id === taskId ? { ...task, reminder: date } : task
        )
      };
    }));
  };

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'roadmap', label: 'My Roadmap', icon: Map },
    { id: 'syllabus', label: 'Syllabus', icon: FileText },
    { id: 'resources', label: 'Study Hub', icon: BookOpen },
    { id: 'pathways', label: 'Career Pathways', icon: Compass },
    { id: 'mentor', label: 'AI Mentor', icon: MessageSquare },
  ];

  const isMentorView = currentView === 'mentor';

  return (
    <div className="h-screen bg-slate-50 flex overflow-hidden">
      {/* Desktop Sidebar (Hidden on Mobile) */}
      <aside className="hidden lg:flex flex-col w-64 bg-slate-900 text-white h-full">
        <div className="p-6">
          <div className="flex items-center space-x-2">
            <div className="h-8 w-8 bg-teal-500 rounded-lg flex items-center justify-center">
              <span className="font-bold text-white text-xl">N</span>
            </div>
            <span className="font-bold text-lg tracking-tight">NursePath BD</span>
          </div>
        </div>

        <nav className="flex-1 px-4 py-4 space-y-1 overflow-y-auto">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setCurrentView(item.id as View)}
              className={`
                w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all
                ${currentView === item.id 
                  ? 'bg-teal-600 text-white shadow-lg shadow-teal-900/20' 
                  : 'text-slate-400 hover:bg-slate-800 hover:text-white'}
              `}
            >
              <item.icon size={20} />
              <span className="font-medium">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-6 border-t border-slate-800">
          <div className="bg-slate-800 rounded-xl p-4">
            <p className="text-xs text-slate-400 mb-2">Completion Status</p>
            <div className="w-full bg-slate-700 h-2 rounded-full overflow-hidden">
              <div 
                className="bg-teal-500 h-full rounded-full transition-all duration-500" 
                style={{ width: `${Math.round((roadmapData.reduce((a, s) => a + s.tasks.filter(t => t.completed).length, 0) / roadmapData.reduce((a, s) => a + s.tasks.length, 0)) * 100)}%` }}
              ></div>
            </div>
            <p className="text-xs text-teal-400 mt-2 font-medium text-center">Keep pushing forward!</p>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 w-full relative bg-slate-50 flex flex-col h-full overflow-hidden">
        
        {/* Header - Show only if NOT mentor view */}
        {!isMentorView && (
            <header className="bg-white flex-shrink-0 border-b border-slate-200 px-4 md:px-6 py-4 flex items-center justify-between shadow-sm z-10">
            <h1 className="text-lg md:text-xl font-bold text-slate-800">
                {navItems.find(i => i.id === currentView)?.label}
            </h1>
            <div className="flex items-center space-x-3">
                <div className="hidden md:block text-right">
                    <p className="text-sm font-bold text-slate-800">Future RN</p>
                    <p className="text-xs text-slate-500">Dhaka, Bangladesh</p>
                </div>
                <div className="h-8 w-8 md:h-9 md:w-9 bg-slate-100 rounded-full flex items-center justify-center text-slate-500 font-bold border border-slate-200">
                    <User size={16} />
                </div>
            </div>
            </header>
        )}

        {/* View Content - Responsive Padding */}
        <div className={`flex-1 overflow-y-auto ${isMentorView ? 'p-0 pb-[60px] lg:pb-0' : 'p-4 md:p-6 pb-24 lg:pb-6'}`}>
          <div className={`mx-auto ${isMentorView ? 'h-full w-full' : 'max-w-7xl'}`}>
            {currentView === 'dashboard' && <Dashboard roadmapData={roadmapData} />}
            {currentView === 'roadmap' && <Roadmap steps={roadmapData} toggleTask={toggleTask} setReminder={setReminder} />}
            {currentView === 'syllabus' && <Syllabus />}
            {currentView === 'resources' && <Resources />}
            {currentView === 'pathways' && <CareerPathways />}
            {currentView === 'mentor' && <AiMentor roadmapData={roadmapData} />}
          </div>
        </div>

        {/* Mobile Bottom Navigation */}
        <MobileNav currentView={currentView} onNavigate={setCurrentView} />
      </main>
    </div>
  );
};

export default App;